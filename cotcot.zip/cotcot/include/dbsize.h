C     Written on Tue  2 Oct 2012 07:43:51 CEST
C     by Jean-Baptiste Caillau - Math. Institute, Bourgogne Univ.
C
C	dbsize.h

      INTEGER          DBSIZE
      PARAMETER       (DBSIZE = 8)
