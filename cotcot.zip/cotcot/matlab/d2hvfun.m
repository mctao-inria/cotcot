function [ hv, dhv, d2hv ] = d2hvfun(t, z, dz, d2z, varargin)
% dhvfun -- Second member of the second variational system.
%
%  Usage
%    [ hv, dhv, d2hv ] = d2hvfun(t, z, dz, d2z, p1, ...)
%
%  Inputs
%    t      real, time
%    z      real vector, state and costate
%    dz     real matrix, Jacobi fields
%    d2z    real matrix, second variation
%    p1     any, optional argument
%    ...
%
%  Outputs
%    hv     real matrix, vector H at time t
%    dhv    real matrix, second member (first variation) at time t
%    d2hv   real matrix, second member (second variation) at time t
%
%  Description
%    Computes the second member of the second variational system associated to H.
%

par = [];
nrhs0 = 4;
for i = 1:(nargin-nrhs0)
  par = [ par varargin{i}(:)' ];
end;

N = size(t, 2)-1;
n = size(z, 1) / 2;
k = size(dz, 2) / (N+1);

zd2z = zeros(2*n, (N+1)*(1+2*k));

for j = 0:N
  zd2z(:, 1+  j*(1+2*k))               = z  (:, 1+j);
  zd2z(:, 2+  j*(1+2*k):1+k+j*(1+2*k)) = dz (:, 1+j*k:(j+1)*k);
  zd2z(:, 2+k+j*(1+2*k):(j+1)*(1+2*k)) = d2z(:, 1+j*k:(j+1)*k);
end;

raw = d2hvfun_m(t, zd2z, par);

hv   = zeros(2*n,  N+1);
dhv  = zeros(2*n, (N+1)*k);
d2hv = zeros(2*n, (N+1)*k);

for j = 0:N
  hv  (:, 1+j)           = raw(:, 1+  j*(1+2*k));
  dhv (:, 1+j*k:(j+1)*k) = raw(:, 2+  j*(1+2*k):1+k+j*(1+2*k));
  d2hv(:, 1+j*k:(j+1)*k) = raw(:, 2+k+j*(1+2*k):(j+1)*(1+2*k));
end;

% Written on Thu 11 Oct 2012 17:23:20 CEST
% by Jean-Baptiste Caillau - Math. Institute, Univ. Bourgogne & CNRS
