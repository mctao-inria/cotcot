function options = rkf45set(varargin)
% rkf45set -- Sets rkf45 options.
%
%  Usage
%    options = rkf45set(name1, value1, ...)
%
%  Inputs
%    name1   string, option name
%    value1  any, option value
%    ...
%
%  Outputs
%    options struct, options
%
%  Description
%    Options are:
%      AbsTol - Absolute error tolerance [ 1e-14 ]
%      RelTol - Relative error tolerance [  1e-8 ]
%
%  See also
%    rkf45, rkf45get
%

options.AbsTol = 1e-14;
options.RelTol =  1e-8;

if (mod(nargin, 2) ~= 0)
  error('Not enough input arguments.');
end;

n = nargin / 2;
for i = 1:n
  switch lower(varargin{1+2*(i-1)})
    case 'abstol'
      options.AbsTol = varargin{2+2*(i-1)};
    case 'reltol'
      options.RelTol = varargin{2+2*(i-1)};
    otherwise
      error(sprintf('Unrecognized property name ''%s''.', ...
	              varargin{1+2*(i-1)}));
  end; 
end;

% Written on Thu 27 Sep 2012 09:51:51 CEST
% by Jean-Baptiste Caillau - Math. Institute, Univ. Bourgogne & CNRS
