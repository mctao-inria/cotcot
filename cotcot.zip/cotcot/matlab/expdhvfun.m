function [ varargout ] = expdhvfun(t, varargin)
% exphvfun -- Exponential of dhv/dz
%
%  Usage
%    [ z, dz, iflag, flags ] = expdhvfun(t, z0, dz0, options, p1, ...)
%
%  Inputs
%    t      real, time
%    z0     real vector, initial flow
%    dz0    real matrix, initial Jacobi fields
%    options struct vector, options
%    p1     any, optional arguments passed to dhvfun
%    ...
%
%  Outputs
%    z      real vector, flow at time t 
%    dz     real matrix, Jacobi fields at time t 
%    iflag  integer, ODE solver output (should be 2)
%    flags  integer array, ODE solver output at each step
%
%  Description
%    Computes the (right) chronological exponential of the variational
%    system associated to hv. Set global var OLDSYNTAX to 1 to use the
%    syntax:
%
%    [ dz, iflag, flags ] = expdhvfun(t, dz0, options, p1, ...)
%
%  See also
%    exphvfun, expd2hvfun, rkf45set, rkf45get
%

global OLDSYNTAX

if ~isempty(OLDSYNTAX)
  if OLDSYNTAX
    oldsyntax = 1;
  else
    oldsyntax = 0;
  end;
else
  oldsyntax = 0;
end;

par = [];

if oldsyntax
  nrhs0 = 3;
  zdz0 = varargin{1};
  options = varargin{2};
  for i = 1:(nargin-nrhs0)
    par = [ par varargin{nrhs0+i-1}(:)' ];
  end;

else
  nrhs0 = 4;
  zdz0 = [ varargin{1} varargin{2} ];
  options = varargin{3};
  for i = 1:(nargin-nrhs0)
    par = [ par varargin{nrhs0+i-1}(:)' ];
  end;

end;

[ raw, iflag, flags ] = expdhvfun_m(t, zdz0, ...
                                    options.AbsTol, options.RelTol, par);

if oldsyntax
  varargout(1) = { raw   };
  varargout(2) = { iflag };
  varargout(3) = { flags };

else
  n = size(varargin{2}, 1) / 2;
  k = size(varargin{2}, 2);
  N = size(t, 2)-1;
  z  = zeros(2*n,  N+1);
  dz = zeros(2*n, (N+1)*k);
  for j = 0:N
    z (:, 1+j)           = raw(:, 1+j*(1+k));
    dz(:, 1+j*k:(j+1)*k) = raw(:, 2+j*(1+k):(j+1)*(1+k));
  end;
  varargout(1) = { z     };
  varargout(2) = { dz    };
  varargout(3) = { iflag };
  varargout(4) = { flags };

end;

% Written on Thu 27 Sep 2012 09:51:51 CEST
% by Jean-Baptiste Caillau - Math. Institute, Univ. Bourgogne & CNRS
