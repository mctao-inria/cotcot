function [ z, iflag, flags ] = exphvfun(t, z0, options, varargin)
% exphvfun -- Exponential of hv
%
%  Usage
%    [ z, iflag, flags ] = exphvfun(t, z0, options, p1, ...)
%
%  Inputs
%    t      real, time 
%    z0     real vector, initial flow
%    options struct vector, options
%    p1     any, optional arguments passed to hvfun
%    ...
%
%  Outputs
%    z      real vector, flow at time t 
%    iflag  integer, ODE solver output (should be 2)
%    flags  integer array, ODE solver output at each step
%
%  Description
%    Computes the (right) chronological exponential of the Hamiltonian
%    vector field hv defined by h.
%
%  See also
%    expdhvfun, expd2hvfun, rkf45set, rkf45get
%

par = [];
nrhs0 = 3;
for i = 1:(nargin-nrhs0)
  par = [ par varargin{i}(:)' ];
end;

[ z, iflag, flags ] = exphvfun_m(t, z0, ...
                                 options.AbsTol, options.RelTol, par);

% Written on Thu 27 Sep 2012 09:51:51 CEST
% by Jean-Baptiste Caillau - Math. Institute, Univ. Bourgogne & CNRS
