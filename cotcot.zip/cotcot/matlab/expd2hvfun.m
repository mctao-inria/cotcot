function [ z, dz, d2z, iflag, flags ] = expd2hvfun(t, z0, dz0, options, varargin)
% exp2hvfun -- Second variation flow
%
%  Usage
%    [ z, dz, d2z, iflag, flags ] = expd2hvfun(t, z0, dz0, options, p1, ...)
%
%  Inputs
%    t      real, time 
%    z0     real vector, initial flow
%    dz0    real matrix, initial Jacobi fields
%    options struct vector, options
%    p1     any, optional arguments passed to dhvfun
%    ...
%
%  Outputs
%    z      real vector, flow at time t 
%    dz     real matrix, Jacobi fields at time t 
%    d2z    real matrix, second variation at time t 
%    iflag  integer, ODE solver output (should be 2)
%    flags  integer array, ODE solver output at each step
%
%  Description
%    Computes the second variation of the flow associated to dz0.
%
%  See also
%    exphvfun, expdhvfun, rkf45set, rkf45get
%

par = [];
nrhs0 = 4;
for i = 1:(nargin-nrhs0)
  par = [ par varargin{i}(:)' ];
end;

[ raw, iflag, flags ] = expd2hvfun_m(t, [ z0 dz0 ], ...
                                     options.AbsTol, options.RelTol, par);
n = size(dz0, 1) / 2;
k = size(dz0, 2);
N = size(t, 2)-1;
z   = zeros(2*n,  N+1);
dz  = zeros(2*n, (N+1)*k);
d2z = zeros(2*n, (N+1)*k);

for j = 0:N
  z  (:, 1+j)           = raw(:, 1+  j*(1+2*k));
  dz (:, 1+j*k:(j+1)*k) = raw(:, 2+  j*(1+2*k):1+k+j*(1+2*k));
  d2z(:, 1+j*k:(j+1)*k) = raw(:, 2+k+j*(1+2*k):(j+1)*(1+2*k));
end;

% Written on Thu 27 Sep 2012 09:51:51 CEST
% by Jean-Baptiste Caillau - Math. Institute, Univ. Bourgogne & CNRS
