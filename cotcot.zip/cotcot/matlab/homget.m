function value = homget(options, name)
% homget -- Gets hom options.
%
%  Usage
%    value = homget(options, name)
%
%  Inputs
%    options struct, options
%    name    string, option name
%
%  Outputs
%    value   any, option value
%
%  Description
%    Options are:
%      kmax    - Maximum number of steps                  [  1e3 ]
%      stepmin - Minimum step length                      [ 1e-6 ]
%      yTol    - Tolerance on zero                        [ 1e-6 ]
%      alpha   - step reduction factor                    [    2 ]
%
%  See also
%    hom, homset
%

switch lower(name)
  case 'kmax'
    value = options.kmax;
  case 'stepmin'
    value = options.stepmin;
  case 'ytol'
    value = options.yTol;
  case 'alpha'
    value = options.alpha;
  otherwise
    error(sprintf('Unrecognized property name ''%s''.', name));
end;

% Written on Tue 21 Jul 2015 19:39:02 CEST
% by Jean-Baptiste Caillau - Math. Institute, UBFC & CNRS / INRIA
