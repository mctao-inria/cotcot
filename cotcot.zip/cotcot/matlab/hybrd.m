function [ x, y, iflag, nfev ] = hybrd(nlefun, x0, options, varargin)
% hybrd -- Hybrid Powell method.
%
%  Usage
%    [ x, y, iflag, nfev ] = hybrd(nlefun, x0, options, p1, ...)
%
%  Inputs
%    nlefun  string, function y = nlefun(x, p1, ...)
%    x0      real vector, initial guess
%    options struct vector, options
%    p1      any, optional argument passed to nlefun
%    ...
%
%  Outputs
%    x       real vector, zero
%    y       real vector, value of nlefun at x
%    iflag   integer, hybrd solver output (should be 1)
%    nfev    integer, number of nlefun evaluations
%
%  Description
%    Matlab interface of Fortran hybrd. Function nlefun must return
%    a column vector.
%
%  See also
%    hybrdset, hybrdget
%

[ n, N ] = size(x0);
opt = options;
if isempty(opt.MaxFev)
  opt.MaxFev = 800 * (n+1);
end;
if isempty(opt.ml)
  opt.ml = n-1;
end;
if isempty(opt.mu)
  opt.mu = n-1;
end;
if isempty(opt.diag)
  opt.diag = ones(n, 1);
end;

x = [];
for i = 1:N
  [ xi, y, iflag, nfev ] = hybrd_m(nlefun    , ...
                                   x0(:, i)  , ...
                                   opt.xTol  , ...
 		   		           opt.MaxFev, ...
				           opt.ml    , ...
				           opt.mu    , ...
				           opt.EpsFcn, ...
				           opt.diag  , ...
				           opt.mode  , ...
				           opt.factor, ...
                                   varargin{:});
  x = [ x xi ];
end;

% Written on Thu 27 Sep 2012 09:51:51 CEST
% by Jean-Baptiste Caillau - Math. Institute, Univ. Bourgogne & CNRS
