function value = hybrdget(options, name)
% hybrdget -- Gets hybrd options.
%
%  Usage
%    value = hybrdget(options, name)
%
%  Inputs
%    options struct, options
%    name    string, option name
%
%  Outputs
%    value   any, option value
%
%  Description
%    Options are:
%      xTol   - Relative tolerance between iterates      [        1e-8 ]
%      MaxFev - Max number of function evaluations       [ 800 x (n+1) ]
%      ml     - Number of banded Jacobian subdiagonals   [         n-1 ]
%      mu     - Number of banded Jacobian superdiagonals [         n-1 ]
%      EpsFcn - Used for FD step length computation      [           0 ]
%      diag   - Used for scaling if mode = 2             [  [1 ... 1]' ]
%      mode   - Automatic scaling if 1, manual if 2      [           1 ]
%      factor - Used for initial step bound              [         1e2 ]
%
%  See also
%    hybrd, hybrdset
%

switch lower(name)
  case 'xtol'
    value = options.xTol;
  case 'maxfev'
    value = options.MaxFev;
  case 'ml'
    value = options.ml;
  case 'mu'
    value = options.mu;
  case 'epsfcn'
    value = options.EpsFcn;
  case 'diag'
    value = options.diag;
  case 'mode'
    value = options.mode;
  case 'factor'
    value = options.factor;
  otherwise
    error(sprintf('Unrecognized property name ''%s''.', name));
end;

% Written on Thu 27 Sep 2012 09:51:51 CEST
% by Jean-Baptiste Caillau - Math. Institute, Univ. Bourgogne & CNRS
