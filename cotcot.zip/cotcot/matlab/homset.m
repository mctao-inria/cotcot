function options = homset(varargin)
% hybrdset -- Sets hom options.
%
%  Usage
%    options = homet(name1, value1, ...)
%
%  Inputs
%    name1   string, option name
%    value1  any, option value
%    ...
%
%  Outputs
%    options struct, options
%
%  Description
%    Options are:
%      kmax     - Maximum number of steps                  [  1e3 ]
%      stepmin  - Minimum step length                      [ 1e-6 ]
%      yTol     - Tolerance on zero                        [ 1e-6 ]
%      alpha    - step reduction factor                    [    2 ]
%
%  See also
%    hom, homget
%

options.kmax    = 1e3;
options.stepmin = 1e-6;
options.yTol    = 1e-6;
options.alpha   = 2;

if (mod(nargin, 2) ~= 0)
  error('Not enough input arguments.');
end;

n = nargin / 2;
for i = 1:n
  switch lower(varargin{1+2*(i-1)})
    case 'kmax'
      options.kmax = varargin{2+2*(i-1)};
    case 'stepmin'
      options.stepmin = varargin{2+2*(i-1)};
    case 'ytol'
      options.yTol = varargin{2+2*(i-1)};
    case 'alpha'
      options.alpha = varargin{2+2*(i-1)};
    otherwise
      error(sprintf('Unknown option: %s.', varargin{1+2*(i-1)}));
  end; 
end;

% Written on Tue 21 Jul 2015 19:39:02 CEST
% by Jean-Baptiste Caillau - Math. Institute, UBFC & CNRS / INRIA
