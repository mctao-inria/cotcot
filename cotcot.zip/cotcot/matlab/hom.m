function [ x, l, y, iflag, flags, k, nfev ] = hom(nlefun, x0, l0, lf, nleopt, options, varargin)
% hom -- Discrete homotopy based on Hybrid Powell method.
%
%  Usage
%    [ x, l, y, iflag, flags, k, nfev ] = hom(nlefun, x0, l0, lf, nleopt, options, p1, ...)
%
%  Inputs
%    nlefun  string, function y = nlefun(x, p1, ...)
%    x0      real vector, solution at l0
%    l0      real, initial lambda
%    lf      real, final lambda
%    nleopt  struct vector, options for hybrd
%    options struct vector, options
%    p1      any, optional argument passed to nlefun
%    ...
%
%  Outputs
%    x       real matrix, path of zeros
%    l       real vector, path of lambdas
%    y       real matrix, path of evaluations
%    iflag   integer, solver output
%    flags   integer array, sequence of hybrd flags
%    k       integer, number of iterations
%    nfev    integer, number of nlefun evaluations
%
%  Description
%    Discrete continuation. Possible outputs are:
%    iflag = 1: lf reached with solution norm <= yTol
%    iflag = 2: lf reached but solution norm > yTol
%    iflag = 3: more than kmax iterates
%    iflag = 4: stepsize smaller than stepmin
%   
%  See also
%    homset, homget, hybrd
%

kmax = options.kmax;
stepmin = options.stepmin;
yTol = options.yTol;
alpha = options.alpha;
iflag_ok = 1;

n = size(x0, 1);

% Check (x0, l0)
[ x, y, iflag, nfev ] = hybrd(nlefun, x0, nleopt, l0, varargin{:});
if ( (iflag ~= iflag_ok) & (abs(y) > yTol) )
  error('Initial point is not a zero.');
end;
l = l0;
xp = x;
lp = 2*l0-lf;
step = 1;
k = 1;

xx = { x };
ll = { l };
yy = { y };
fflags = { iflag };

% Main loop
while ( (l ~= lf) & (k < kmax) & (abs(l-lp) > stepmin) )

  zp = [ xp; lp ];
  z = [ x; l ];
  dz = z - zp;
  stepf = (lf-l)/dz(n+1);
  if step < stepf
    zi = z + step*dz;
    xi = zi(1:n);
    ln = zi(n+1);
  else
    zi = z + stepf*dz;
    xi = zi(1:n);
    ln = lf;
  end;

  fprintf(1, '\n lambda: %1.14e\n', ln);
  [ xn, yn, iflag, nf ] = hybrd(nlefun, xi, nleopt, ln, varargin{:});
  nfev = nfev + nf;

  if (abs(yn) <= yTol)
    xx = { xx{:} xn };
    ll = { ll{:} ln };
    yy = { yy{:} yn };
    fflags = { fflags{:} iflag };
    xp = x;
    lp = l;
    x = xn;
    l = ln;
    step = 1;
  else
    step = step / alpha;
  end;
        
  k = k+1;

end;

kk = size(xx, 2);
x = zeros(n, kk);
l = zeros(1, kk);
y = zeros(n, kk);
flags = zeros(1, kk);
for i = 1:kk
  x(:, i) = xx{i};
  l(i) = ll{i};
  y(:, i) = yy{i};
  flags(i) = fflags{i};
end;

if (l(end) == lf) & (abs(y(:,end)) <= yTol)
  iflag = 1;
elseif (l(end) == lf) & (abs(y(:,end)) > yTol)
  iflag = 2;
elseif (k >= kmax)
  iflag = 3;
else
  iflag = 4;
end;

% Written on Tue 21 Jul 2015 19:39:02 CEST
% by Jean-Baptiste Caillau - Math. Institute, UBFC & CNRS / INRIA
