function [ hv, dhv ] = dhvfun(t, z, dz, varargin)
% dhvfun -- Second member of the first variational system.
%
%  Usage
%    [ hv, dhv ] = dhvfun(t, z, dz, p1, ...)
%
%  Inputs
%    t      real, time
%    z      real vector, state and costate
%    dz     real matrix, Jacobi fields
%    p1     any, optional argument
%    ...
%
%  Outputs
%    hv     real matrix, vector H at time t
%    dhv    real matrix, second member at time t
%
%  Description
%    Computes the second member of the first variational system associated to H.
%

par = [];
nrhs0 = 3;
for i = 1:(nargin-nrhs0)
  par = [ par varargin{i}(:)' ];
end;

N = size(t, 2)-1;
n = size(z, 1) / 2;
k = size(dz, 2) / (N+1);

zdz = zeros(2*n, (N+1)*(1+k));

for j = 0:N
  zdz(:, 1+j*(1+k))             = z (:, 1+j);
  zdz(:, 2+j*(1+k):(j+1)*(1+k)) = dz(:, 1+j*k:(j+1)*k);
end;

raw = dhvfun_m(t, zdz, par);

hv  = zeros(2*n,  N+1);
dhv = zeros(2*n, (N+1)*k);

for j = 0:N
  hv (:, 1+j)           = raw(:, 1+j*(1+k));
  dhv(:, 1+j*k:(j+1)*k) = raw(:, 2+j*(1+k):(j+1)*(1+k));
end;

% Written on Thu 11 Oct 2012 11:49:15 CEST
% by Jean-Baptiste Caillau - Math. Institute, Univ. Bourgogne & CNRS
