function s = sfun(xi, options)
% sfun -- Shooting function
%
%  Usage
%    s = sfun(xi, options)
%
%  Inputs
%    xi     real vector, shooting variable
%    options struct, options passed to exphvfun
%
%  Outputs
%    s      real vector, shooting value
%
%  Description
%    Computes the shooting function.
%
%  See also
%    exphvfun
%

global t0 tf x0 xf;

tf  = xi(1);
p0  = xi(2:end);

t  = [ t0 tf ]; 
z0 = [ x0; p0 ];
[ z, iflag ] = exphvfun(t, z0, options);
zf = z(:, end);
s = zf(1:2) - xf;
h = hfun(tf, zf); 
s = [ s; h ]; % free tf

% Written on Tue Jan 11 13:07:08 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
