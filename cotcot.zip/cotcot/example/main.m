% main -- 2D hyperbolic case, dx/dt = u, dy/dt = 1-u^2+x^2.
% First conjugate time at pi.
%

format long;
clear all, close all;
global t0 tf x0 xf;

global OLDSYNTAX
OLDSYNTAX = 1;

t0 = 0;
x0 = [  0 0 ]';
xf = [ 10 0 ]';
n = size(x0, 1); % state dimension

% Extremal
odeopt = rkf45set;
nleopt = hybrdset;
xii = [ 10 1 1 ]';
tic; [ xi, s, iflag, nfev ] = hybrd('sfun', xii, nleopt, odeopt), toc
tf = xi(1), p0 = xi(2:end);

% Jacobi fields
k = n-1; % regular case, k = n-1
N = 10000;
tc = 3 * tf;
dt = tc/N;
t  = 0:dt:tc;
z0 = [ x0; p0 ];
[ dummy, dp0 ] = gram(p0);
dz0 = [ zeros(n, k); dp0 ];
dz0 = [ z0 dz0 ];
[ dz, iflag ] = expdhvfun(t, dz0, odeopt); iflag 

% Graphs
[ h, de, sv ] = draw(t, dz);
itcs = find((de(1:end-1).*de(2:end)) <= 0);
itcs = itcs(2:end);
tcs  = t(itcs)

% More...
for i = 1:length(tcs)
  t1 = tcs(i);
  dz1 = dz(:, 1+(itcs(i)-1)*(k+1):itcs(i)*(k+1)); 
  tic; [ tcs(i), d, iflag, nfev ] = hybrd('dfun', t1, nleopt, ...
                                          t1, dz1, odeopt); iflag, toc
  subplot(2, 1, 1), hold on, plot(tcs(i), 0,'g*'), hold off, drawnow;
  subplot(2, 1, 2), hold on, plot(tcs(i), 0,'g*'), hold off, drawnow;
end;
zoom on;
tcs

% Written on Tue Jan 11 18:42:32 CET 2005
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
