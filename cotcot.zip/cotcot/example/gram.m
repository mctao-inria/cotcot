function [ B, C ] = gram(A)
% gram -- Gram-Schmidt orthonormalization
%
%  Usage
%    [ B, C ] = gram(A)
%
%  Inputs
%    A      m x n matrix
%
%  Outputs
%    B      m x r unitary matrix, r = rank(A)
%    C      m x (m-r) unitary matrix, r = rank(A)
%
%  Description
%    The range of B is Im A, the range of C its orthogonal.
%
%  See also
%    svd
%

[ U, S, V ] = svd(A);
r = length(find(S));
B = U(:, 1:r);
C = U(:, (r+1):end);
