% startup.m
%

addpath('/Users/caillau/research/code/cotcot/matlab/');

% Written on Thu 19 Jan 2017 08:59:10 CET by cotcot
