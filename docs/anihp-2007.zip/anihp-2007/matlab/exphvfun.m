function [ exphv, iflag, flags ] = exphvfun(t, z0, options, varargin)
% exphvfun -- Exponential of hv
%
%  Usage
%    [ exphv, iflag, flags ] = exphvfun(t, z0, options, p1, ...)
%
%  Inputs
%    t      real, time 
%    z0     real vector, initial flow
%    options struct vector, options
%    p1     any, optional arguments passed to hvfun
%    ...
%
%  Outputs
%    exphv  real vector, flow at time t 
%    iflag  integer, ODE solver output (should be 2)
%    flags  integer array, ODE solver output at each step
%
%  Description
%    Computes the (right) chronological exponential of the Hamiltonian
%    vector field hv defined by h.
%
%  See also
%    expdhvfun, rkf45set, rkf45get
%

par = [];
nrhs0 = 3;
for i = 1:(nargin-nrhs0)
  par = [ par varargin{i}(:)' ];
end;

[ exphv, iflag, flags ] = exphvfun_m(t, z0, ...
                                     options.AbsTol, options.RelTol, par);

% Written on Fri Jan  7 12:38:41 CET 2005
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
