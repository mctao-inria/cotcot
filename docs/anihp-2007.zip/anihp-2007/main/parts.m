function l = parts(t)
% parts -- Parts.
%
%  Usage
%    l = parts(t)
%
%  Inputs
%    t      integer array, strictly increasing
%
%  Outputs
%    l      integer array list
%
%  Description
%    Splits t into its sequentially connected parts.
%

t = t(:)';
if isempty(t) l = { [] }; return; end;

if ~isempty(find( t-floor(t) ))
  error('t must be an integer array.')
end;

if ~isempty(find( diff(t) <= 0 ))
  error('t must be a strictly increasing integer array.')
end;

l  = {};
s  = [ ];
i0 = t(1)-1;

for i = t
  if i-i0 == 1
    s = [ s i ];
  else
    if ~isempty(s) l = { l{:} s }; end;
    s = [ i ];
  end;
  i0 = i;
end;

if ~isempty(s) l = { l{:} s }; end;

% Written on Wed Nov 23 16:29:49 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
