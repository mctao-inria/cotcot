% main -- Riemannian form of the 2D averaged problem,
% geodesics and spheres.
% note: view(0, 0) to see (n,ex) plane on fig. 1
%

format long;
clear all;
close all;
global t0 tf x0;

% Initializations
N0     =   10; % number of spheres (3)
N1     =  200; % discretization size on alph (50)
N2     =   20; % discretization size on bet  (50)
N3     = 1000; % discretization size on each geodesic (1000)

alph_0 = 0;           alph_f = 2*pi;
bet_0  = pi/2;        bet_f  = pi/2;
t0     = 0;           tf     = 2.0;

coord  = 1; % 0: almost flat (x,y,z), 1: cartesian (n, ex, ey)
conj   = 0; % 0: no computation, ~0: conjugate point computation

lambda = 1.0;
sigma  = (1-lambda)*1 + lambda*sqrt(2/5);

nn0    = 1;
e0     = .75;
om0    = 0;
      
r0     = (6/5)*nn0^(5/6);
th0    = (5/sqrt(2)) * om0; 
phi0   = sqrt(5/2) * asin(e0);
      
x0     = [ r0 th0 phi0 ]';
si0    = sign(cos(sigma*phi0));
ds0    = [ 1 r0^2*(sin(sigma*phi0))^2/(1+4*lambda*(cos(sigma*phi0))^2) r0^2 ]';
n      = size(x0, 1); % state dimension
if conj
  dz0  = [ zeros(n); eye(n) ];
  nj   = n; % number of Jacobi fields
else
  nj   = 0;
end;

switch coord, case 0
  x1l  = 'x';
  x2l  = 'y';
  x3l  = 'z';
case 1
  x1l = 'e_x';
  x2l = 'e_y';
  x3l = 'n';
otherwise
  error('Unknown value of coord.');
end;

% Geodesics
switch coord, case 0
  x10  = r0*sin(phi0)*cos(th0);
  x20  = r0*sin(phi0)*sin(th0);
  x30  = r0*cos(phi0);
case 1
  x10 = sin(sqrt(2/5)*phi0)*cos(sqrt(2)*th0/5);
  x20 = sin(sqrt(2/5)*phi0)*sin(sqrt(2)*th0/5);
  x30 = (5*r0/6)^(6/5);
otherwise
  error('Unknown value of coord.');
end;
fig1 = 1; figure(fig1); plot3(x10, x20, x30);
set(fig1, 'Position', [20 288 512 384]), hold on;
switch coord, case 0
  axis equal;
case 1
  [];
otherwise
  error('Unknown value of coord.');
end;

if (N1 <= 1) | (alph_0 == alph_f)
  alph = alph_0;
  N1   = 1;
else
  dalph  = (alph_f-alph_0)/(N1-1);
  alph   = alph_0:dalph:alph_f;
end;

if (N2 <= 1) | (bet_0 == bet_f)
  bet  = bet_0;
  N2   = 1;
else
  dbet = (bet_f-bet_0)/(N2-1);
  bet  = bet_0:dbet:bet_f;
end;

if (N3 <= 1) | (t0 == tf)
  t    = t0;
  N3   = 1;
else
  dt   = (tf-t0)/(N3-1);
  t    = t0:dt:tf;
end;
dN3 = max([ 1 floor(N3/N0) ]);
it1 = 1:N3;
it2 = [ 1:dN3:(N3+1-dN3) N3 ];

x1    = zeros(N1, N2, N3);
x2    = zeros(N1, N2, N3);
x3    = zeros(N1, N2, N3);
if conj,
de    = zeros(N1, N2, N3); end;
flags = zeros(N1, N2, N3);

for j = 1:N2, for i = 1:N1

  if abs(bet(j)) == pi/2, cbet = 0; else cbet = cos(bet(j)); end;
  p0 = [ sin(bet(j))*cos(alph(i))
	    cbet
         sin(bet(j))*sin(alph(i)) ];
  p0 = p0 .* sqrt(ds0);
  z0 = [ x0; p0 ];
  
  odeopt = rkf45set; flag_ok = 2;
  if conj
    [ dz, iflag, flags(i, j, :) ] = ...
      expdhvfun(t, [ z0 dz0 ], odeopt, lambda, sigma);
  else
    [ dz, iflag, flags(i, j, :) ] = ...
      exphvfun(t,    z0,       odeopt, lambda, sigma);
  end;
    
  r   = dz(1, 1+(0:(N3-1))*(1+nj));
  th  = dz(2, 1+(0:(N3-1))*(1+nj));
  phi = dz(3, 1+(0:(N3-1))*(1+nj));

switch coord, case 0
  x1(i, j, :) = r.*sin(phi).*cos(th);
  x2(i, j, :) = r.*sin(phi).*sin(th);
  x3(i, j, :) = r.*cos(phi)         ;
case 1
  x1(i, j, :) = sin(sqrt(2/5)*phi).*cos(sqrt(2)*th/5);
  x2(i, j, :) = sin(sqrt(2/5)*phi).*sin(sqrt(2)*th/5);
  x3(i, j, :) = (5*r/6).^(6/5);
otherwise
  error('Unknown value of coord.');
end;

  flags(i, j, :) = (flags(i, j, :) == flag_ok);
  flags(i, j, :) = reshape(flags(i, j, :), 1, N3) ...
                 & (r > 0)                        ... 
                 & (sign(cos(sigma*phi)) == si0) ; 
  iit1 = it1(find( flags(i, j, it1) )); N31 = size(iit1, 2); 
  iit2 = it2(find( flags(i, j, it2) )); N32 = size(iit2, 2); 

  if conj
    for k = iit1
      de(i, j, k) = det(reshape(dz(1:n, 2+(k-1)*(1+nj):k*(1+nj)), n, nj)); 
    end;
    iit3 = find( de(i, j, iit1(1:end-1)) .* de(i, j, iit1(2:end)) < 0 );
    iit3 = iit1(iit3);
    N33  = size(iit3, 2); 
  end;

  plot3(reshape(x1(i, j, iit1), 1, N31), ...
        reshape(x2(i, j, iit1), 1, N31), ...
        reshape(x3(i, j, iit1), 1, N31));
  plot3(reshape(x1(i, j, iit2), 1, N32), ...
        reshape(x2(i, j, iit2), 1, N32), ...
        reshape(x3(i, j, iit2), 1, N32), 'r.');
  if conj,
  plot3(reshape(x1(i, j, iit3), 1, N33), ...
        reshape(x2(i, j, iit3), 1, N33), ...
        reshape(x3(i, j, iit3), 1, N33), 'g.'); end;

end, fprintf(1, '\b\b\b\b\b%3.0f%% ', 100*j/N2), drawnow, end, hold off;
daxes3(x10, x20, x30, 'k');
xlabel(x1l), ylabel(x2l), zlabel(x3l);

% Spheres (1)
fig2 = 2; figure(fig2); plot3(x10, x20, x30);
set(fig2, 'Position', [585 287 512 384]), hold on;
switch coord, case 0
  axis equal;
case 1
  [];
otherwise
  error('Unknown value of coord.');
end;

for k = it2
  for j = 1:N2
    li = parts(find( flags(:, j, k) ));
    for i = li
      plot3(x1(i{:}, j, k), x2(i{:}, j, k), x3(i{:}, j, k));
    end;
  end;

  for i = 1:N1
    lj = parts(find( flags(i, :, k) ));
    for j = lj
      plot3(x1(i, j{:}, k), x2(i, j{:}, k), x3(i, j{:}, k));
    end;
  end;
end, hold off;
daxes3(x10, x20, x30, 'k');
xlabel(x1l), ylabel(x2l), zlabel(x3l);

% Spheres (2)
fig3 = 3; figure(fig3);
set(fig3, 'Position', [20 21 512 384]);

subplot(2, 2, 2), hold on; % xy
switch coord, case 0
  axis ij;
  axis equal;
case 1
  axis ij;
otherwise
  error('Unknown value of coord.');
end;
for k = it2
  for j = 1:N2
    li = parts(find( flags(:, j, k) ));
    for i = li
      plot (x2(i{:}, j, k), x1(i{:}, j, k));
    end;
  end;

  for i = 1:N1
    lj = parts(find( flags(i, :, k) ));
    for j = lj
      plot(x2(i, j{:}, k), x1(i, j{:}, k));
    end;
  end;
end, hold off, zoom on;
daxes(x20, x10, 'k');
xlabel(x2l), ylabel(x1l);

subplot(2, 2, 3), hold on; % xz
switch coord, case 0
  axis equal;
case 1
  [];
otherwise
  error('Unknown value of coord.');
end;
for k = it2
  for j = 1:N2
    li = parts(find( flags(:, j, k) ));
    for i = li
      plot (x1(i{:}, j, k), x3(i{:}, j, k));
    end;
  end;

  for i = 1:N1
    lj = parts(find( flags(i, :, k) ));
    for j = lj
      plot(x1(i, j{:}, k), x3(i, j{:}, k));
    end;
  end;
end, hold off, zoom on;
daxes(x10, x30, 'k');
xlabel(x1l), ylabel(x3l);

subplot(2, 2, 4), hold on; % yz
switch coord, case 0
  axis equal;
case 1
  [];
otherwise
  error('Unknown value of coord.');
end;
for k = it2
  for j = 1:N2
    li = parts(find( flags(:, j, k) ));
    for i = li
      plot (x2(i{:}, j, k), x3(i{:}, j, k));
    end;
  end;

  for i = 1:N1
    lj = parts(find( flags(i, :, k) ));
    for j = lj
      plot(x2(i, j{:}, k), x3(i, j{:}, k));
    end;
  end;
end, hold off, zoom on;
daxes(x20, x30, 'k');
xlabel(x2l), ylabel(x3l);

switch coord, case 0
  figure(1), axis normal, axis equal;
  figure(2), axis normal, axis equal;
  figure(3);
case 1
  [];
otherwise
  error('Unknown value of coord.');
end;

% Written on Mon Jan 30 18:42:03 CET 2006 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
