      SUBROUTINE HFUN(T, N, Z, LPAR, PAR, H) 
      IMPLICIT NONE
C     Written on Wed Nov  2 12:29:21 CET 2005 
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function h = hfun(t, y, p1, ...). Hamiltonian of the problem.

C     .. Arguments ..
C     T                (input) DOUBLE PRECISION
C                      Time
C     N                (input) INTEGER,
C                      State dimension
C     Z                (input) DOUBLE PRECISION array, dimension 2*N
C                      Costate
C     LPAR             (input) INTEGER,
C                      Number of optional parameters
C     PAR              (input) DOUBLE PRECISION array, dimension LPAR
C                      Optional parameters
C     H                (output) DOUBLE PRECISION
C                      Hamiltonian
      INTEGER          N
      INTEGER          LPAR

      DOUBLE PRECISION T
      DOUBLE PRECISION Z(2*N)
      DOUBLE PRECISION PAR(LPAR)
      DOUBLE PRECISION H

C     .. Local declarations ..
      DOUBLE PRECISION R
      DOUBLE PRECISION THETA
      DOUBLE PRECISION PHI
      DOUBLE PRECISION PR
      DOUBLE PRECISION PTHETA
      DOUBLE PRECISION PPHI
      DOUBLE PRECISION LAMBDA
      DOUBLE PRECISION SIGMA
      DOUBLE PRECISION SPHI
      DOUBLE PRECISION CSPHI
      DOUBLE PRECISION SSPHI
      DOUBLE PRECISION CT

      DOUBLE PRECISION NZERO
	PARAMETER(NZERO = 1.0D-16)

C     .. First executable statement ..
      IF (N.NE.3) THEN
        CALL MEXERRMSGTXT('State dimension should be 3.')
      END IF

      IF (LPAR.NE.2) THEN
        CALL MEXERRMSGTXT('Number of parameters should be 2.')
      END IF

      R      = Z(1)
      THETA  = Z(2)
      PHI    = Z(3)
      PR     = Z(4)
      PTHETA = Z(5)
      PPHI   = Z(6)

      LAMBDA = PAR(1)
      SIGMA  = PAR(2)

      IF (R.EQ.0.0D0) THEN
        R = NZERO ! avoids mere zero division
        CALL MEXWARNMSGTXT('Null r, set to NZERO.')
      END IF

	SPHI  = SIGMA*PHI
	CSPHI = COS(SPHI)
	SSPHI = SIN(SPHI)

      IF (SSPHI.EQ.0.0D0) THEN
        SSPHI = NZERO ! avoids mere zero division
        CALL MEXWARNMSGTXT('Null sin(sigma phi), set to NZERO.')
      END IF

	CT = ( 1.0D0 + 4.0D0*LAMBDA*CSPHI**2 ) / SSPHI**2
      H  = 0.5D0 * ( PR**2 + (1.0D0/R**2) * ( CT*PTHETA**2 + PPHI**2) )

      RETURN
      END
