% main.m
%

ti =      '\n\t\b"Riemannian metric of the averaged energy minimization problem"\n';
ti = [ ti '\tin orbital transfer with low thrust"\n';     ];
ti = [ ti '\tBernard Bonnard and Jean-Baptiste Caillau\n' ];
ti = [ ti '\tAnn. I. H. Poincare, to appear\n'            ];
title = ti;
entries = { { 'Figure 3'  'fig3'  } ...
            { 'Figure 4a' 'fig4a' } ...
            { 'Figure 4b' 'fig4b' } ...
            { 'Figure 4c' 'fig4c' } ...
            { 'Figure 4d' 'fig4d' } ...
            { 'Figure 5'  'fig5'  } ...
            { 'Figure 6a' 'fig6a' } ...
            { 'Figure 6b' 'fig6b' } };
nentries = size(entries, 2);

fprintf(1,'\n');
fprintf(1, [ title '\n' ]);
fprintf(1,'\n');
for i = 1:nentries
  fprintf(1,'\t%d. %s\n',i,entries{i}{1});
end;
fprintf(1,'\n');
fprintf(1,'\t0. Quit\n');
fprintf(1,'\n');

ch = -1; while (ch == -1)
  fprintf(1,'Choice ? '); ch = input('');
  if isempty(ch) ch = -1; end;
  if (ch < 0) | (ch > nentries) ch = -1; end;
end;

if (ch == 0)
  close all
else
  fprintf(1, '\n%d. %s\n\n', ch, entries{ch}{1});
  eval(entries{ch}{2});
  main;
end;

% Written on Tue Feb 21 14:34:38 CET 2006 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
