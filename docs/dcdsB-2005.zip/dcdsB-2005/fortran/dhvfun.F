      SUBROUTINE DHVFUN(T, N, K, DZ, LPAR, PAR, DHV) 
      IMPLICIT NONE
C     Written on Fri Dec 31 07:29:15 CET 2004 
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function dhv = dhvfun(t, dz, p1, ...). Defines the second member
C     dhv(t, dy) of the variational system. 

C     .. Global ..
#include "constants.h"

C     .. Arguments ..
C     T                (input) DOUBLE PRECISION
C                      Time
C     N                (input) INTEGER,
C                      State dimension
C     K                (input) INTEGER,
C                      Number of Jacobi fields
C     DZ               (input) DOUBLE PRECISION array, dimension 2*N x (1+K)
C                      Jacobi fields
C     LPAR             (input) INTEGER,
C                      Number of optional parameters
C     PAR              (input) DOUBLE PRECISION array, dimension LPAR
C                      Optional parameters
C     DHV              (output) DOUBLE PRECISION array, dimension 2*N x (1+K)
C                      Second member of the variational system
      INTEGER          N
      INTEGER          K
      INTEGER          LPAR

      DOUBLE PRECISION T
      DOUBLE PRECISION DZ(2*N, 1+K)
      DOUBLE PRECISION PAR(LPAR)
      DOUBLE PRECISION DHV(2*N, 1+K)

C     .. Local declarations ..
      INTEGER          I
      INTEGER          J
      DOUBLE PRECISION G_Z(N2MAX, N2MAX)
      DOUBLE PRECISION G_HV(N2MAX, N2MAX)

C     .. First executable statement ..
      DO I = 1, 2*N
        DO J = 1, 2*N
           G_Z(I,J) = 0.0D0
        END DO
      END DO
      DO I = 1, 2*N
        G_Z(I,I) = 1.0D0
      END DO
      CALL G_HVFUN(2*N, T, N, DZ(1, 1), G_Z, LPAR, PAR, DHV(1, 1), G_HV)
      CALL DGEMM('T', 'N', 2*N, K, 2*N, 1.0D0, G_HV, N2MAX,
     &           DZ(1, 2), 2*N, 0.0D0, DHV(1, 2), 2*N)

      RETURN
      END
