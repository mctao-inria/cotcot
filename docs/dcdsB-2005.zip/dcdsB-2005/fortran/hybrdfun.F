      SUBROUTINE HYBRDFUN(N, X, Y, IFLAG) 
      IMPLICIT NONE
C     Written on Fri Thu Sep 30 14:45:48 CEST 2004 
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function y = nlefun(x, p1, ...). HYBRD function argument.
C     Matlab gateway.

C     .. Global ..
      INTEGER          NVINMAX
      PARAMETER       (NVINMAX = 32)
      INTEGER          NVIN
      INTEGER          MXVIN(NVINMAX)
      INTEGER          NFEV2
      CHARACTER*32     NLEFUN

      COMMON           /CNVIN/NVIN
      COMMON           /CMXVIN/MXVIN
      COMMON           /CNFEV2/NFEV2
      COMMON           /CNLEFUN/NLEFUN

C     .. Arguments ..
C     N                (input) INTEGER
C                      Dimension
C     X                (input) DOUBLE PRECISION array, dimension N
C                      Argument
C     Y                (output) DOUBLE PRECISION array, dimension N
C                      Result
C     IFLAG            (input) INTEGER
C                      Solver flag
      INTEGER          N
      INTEGER          IFLAG
      DOUBLE PRECISION X(N)
      DOUBLE PRECISION Y(N)

C     .. Local declarations ..
      INTEGER          NLHS0 
      PARAMETER       (NLHS0 = 1)
      INTEGER          NRHS0 
      PARAMETER       (NRHS0 = 1)
      INTEGER          NRHS
      INTEGER          NLHS
      INTEGER          PLHS(NLHS0)
      INTEGER          PRHS(NRHS0 + NVINMAX)
      INTEGER          PX
      INTEGER          PY
      INTEGER          RET
      INTEGER          MXGETM
      INTEGER          MXGETN
      INTEGER          MXGETPR
      INTEGER          MXCREATEDOUBLEMATRIX
      INTEGER          MEXCALLMATLAB
      INTEGER          I
      DOUBLE PRECISION DNRM2

C     .. First executable statement ..
      NRHS = NRHS0 + NVIN
      PRHS(1) = MXCREATEDOUBLEMATRIX(N, 1, 0)
      PX = MXGETPR(PRHS(1))
      CALL MXCOPYREAL8TOPTR(X, PX, N)     

      DO I = 1, NVIN
        PRHS(NRHS0 + I) = MXVIN(I)
      END DO

      NLHS = NLHS0 

      RET = MEXCALLMATLAB(NLHS, PLHS, NRHS, PRHS, NLEFUN)
      IF (RET.NE.0) THEN
        CALL MEXERRMSGTXT('Problem calling nlefun.')
      END IF
      NFEV2 = NFEV2 + 1 

      IF (MXGETM(PLHS(1)) * MXGETN(PLHS(1)).NE.N) THEN
        CALL MEXERRMSGTXT('nlefun result has wrong dimension.')
      ENDIF
      PY = MXGETPR(PLHS(1))
      CALL MXCOPYPTRTOREAL8(PY, Y, N)     

      WRITE(*, '(    i6, $)') NFEV2
      WRITE(*, '(e23.15, $)') DNRM2(N, Y, 1)
      WRITE(*, '(e23.15, $)') DNRM2(N, X, 1)
      DO I = 1, N
        WRITE(*, '( e11.3, $)') X(I)
      END DO
      WRITE(*, *) ''

      RETURN
      END
