      SUBROUTINE MEXFUNCTION(NLHS, PLHS, NRHS, PRHS)
      IMPLICIT NONE
C     Written on Sat Oct  2 15:45:48 CEST 2004 
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function [ x, y, iflag, nfev ] = hybrd_m(nlefun, x0, xTol,
C     MaxFev, ml, mu, EpsFcn, diag, mode, factor, p1, ...).
    
C     .. Global ..
      INTEGER          NVINMAX
      PARAMETER       (NVINMAX = 32)
      INTEGER          NVIN
      INTEGER          MXVIN(NVINMAX)
      INTEGER          NFEV2
      CHARACTER*32     NLEFUN

      COMMON           /CNVIN/NVIN
      COMMON           /CMXVIN/MXVIN
      COMMON           /CNFEV2/NFEV2
      COMMON           /CNLEFUN/NLEFUN

C     .. Arguments ..
C     NLHS             (input) INTEGER
C                      Number of inputs
C     PLHS             (input) INTEGER ARRAY
C                      Inputs
C     NRHS             (input) INTEGER
C                      Number of outputs
C     PRHS             (input) INTEGER ARRAY
C                      Outputs
      INTEGER          NLHS
      INTEGER          NRHS
      INTEGER          PLHS(*)
      INTEGER          PRHS(*)

C     .. Local declarations ..
      INTEGER          NLHS0
      PARAMETER       (NLHS0 =  4)
      INTEGER          NRHS0
      PARAMETER       (NRHS0 = 10)
      INTEGER          PNLEFUN
      INTEGER          PX0
      INTEGER          PXTOL
      INTEGER          PMAXFEV
      INTEGER          PML
      INTEGER          PMU
      INTEGER          PEPSFCN
      INTEGER          PDIAG
      INTEGER          PMODE
      INTEGER          PFACTOR
      INTEGER          PX
      INTEGER          PY
      INTEGER          PIFLAG
      INTEGER          PNFEV
      INTEGER          MAXFEV
      INTEGER          ML
      INTEGER          MU
      INTEGER          MODE
      INTEGER          NPRINT
      INTEGER          IFLAG
      INTEGER          NFEV
      INTEGER          N
      INTEGER          LR
      INTEGER          RET
      INTEGER          PFJAC
      INTEGER          PR
      INTEGER          PQTF
      INTEGER          PWA1
      INTEGER          PWA2
      INTEGER          PWA3
      INTEGER          PWA4
      INTEGER          I
      INTEGER          MXGETSTRING
      INTEGER          MXGETPR
      INTEGER          MXGETM
      INTEGER          MXGETN
      INTEGER          MXCREATEDOUBLEMATRIX
      DOUBLE PRECISION MMAXFEV
      DOUBLE PRECISION MML
      DOUBLE PRECISION MMU
      DOUBLE PRECISION MMODE
      DOUBLE PRECISION IIFLAG
      DOUBLE PRECISION NNFEV
      EXTERNAL         HYBRDFUN

C     .. Check inputs ..
      IF (NRHS.LT.NRHS0) THEN
        CALL MEXERRMSGTXT('Not enough input arguments.')
      ELSEIF (NRHS.GT.(NRHS0 + NVINMAX)) THEN
        CALL MEXERRMSGTXT('Too many input arguments.')
      ENDIF

C     .. Check outputs ..
      IF (NLHS.LT.NLHS0) THEN
        CALL MEXERRMSGTXT('Not enough output arguments.')
      ELSEIF (NLHS.GT.NLHS0) THEN
        CALL MEXERRMSGTXT('Too many output arguments.')
      ENDIF

C     .. Get inputs ..
      PNLEFUN = PRHS(1)
      RET = MXGETSTRING(PNLEFUN, NLEFUN, 32)
      IF (RET.NE.0) THEN
        CALL MEXERRMSGTXT('nlefun must be a string.')
      END IF

      IF (MXGETN(PRHS(2)).NE.1) THEN
        CALL MEXERRMSGTXT('x0 must have one column.')
      ENDIF
      PX0 = MXGETPR(PRHS(2))
      N   = MXGETM(PRHS(2))

      IF (MXGETM(PRHS(3)).NE.1) THEN
        CALL MEXERRMSGTXT('xTol must be scalar.')
      ELSEIF (MXGETN(PRHS(3)).NE.1) THEN
        CALL MEXERRMSGTXT('xTol must be scalar.')
      ENDIF
      PXTOL = MXGETPR(PRHS(3))

      IF (MXGETM(PRHS(4)).NE.1) THEN
        CALL MEXERRMSGTXT('MaxFev must be scalar.')
      ELSEIF (MXGETN(PRHS(4)).NE.1) THEN
        CALL MEXERRMSGTXT('MaxFev must be scalar.')
      ENDIF
      PMAXFEV = MXGETPR(PRHS(4))
      CALL MXCOPYPTRTOREAL8(PMAXFEV, MMAXFEV, 1)
      MAXFEV = INT(MMAXFEV)

      IF (MXGETM(PRHS(5)).NE.1) THEN
        CALL MEXERRMSGTXT('ml must be scalar.')
      ELSEIF (MXGETN(PRHS(5)).NE.1) THEN
        CALL MEXERRMSGTXT('ml must be scalar.')
      ENDIF
      PML = MXGETPR(PRHS(5))
      CALL MXCOPYPTRTOREAL8(PML, MML, 1)
      ML = INT(MML)

      IF (MXGETM(PRHS(6)).NE.1) THEN
        CALL MEXERRMSGTXT('mu must be scalar.')
      ELSEIF (MXGETN(PRHS(6)).NE.1) THEN
        CALL MEXERRMSGTXT('mu must be scalar.')
      ENDIF
      PMU = MXGETPR(PRHS(6))
      CALL MXCOPYPTRTOREAL8(PMU, MMU, 1)
      MU = INT(MMU)

      IF (MXGETM(PRHS(7)).NE.1) THEN
        CALL MEXERRMSGTXT('EpsFcn must be scalar.')
      ELSEIF (MXGETN(PRHS(7)).NE.1) THEN
        CALL MEXERRMSGTXT('EpsFcn must be scalar.')
      ENDIF
      PEPSFCN = MXGETPR(PRHS(7))

      IF (MXGETN(PRHS(8)).NE.1) THEN
        CALL MEXERRMSGTXT('diag must have one column.')
      ELSEIF (MXGETM(PRHS(8)).NE.N) THEN
        CALL MEXERRMSGTXT('diag must have n rows.')
      ENDIF
      PDIAG = MXGETPR(PRHS(8))

      IF (MXGETM(PRHS(9)).NE.1) THEN
        CALL MEXERRMSGTXT('mode must be scalar.')
      ELSEIF (MXGETN(PRHS(9)).NE.1) THEN
        CALL MEXERRMSGTXT('mode must be scalar.')
      ENDIF
      PMODE = MXGETPR(PRHS(9))
      CALL MXCOPYPTRTOREAL8(PMODE, MMODE, 1)
      MODE = INT(MMODE)

      IF (MXGETM(PRHS(10)).NE.1) THEN
        CALL MEXERRMSGTXT('Factor must be scalar.')
      ELSEIF (MXGETN(PRHS(10)).NE.1) THEN
        CALL MEXERRMSGTXT('Factor must be scalar.')
      ENDIF
      PFACTOR = MXGETPR(PRHS(10))

      NVIN = NRHS - NRHS0
      DO I = 1, NVIN
        MXVIN(I) = PRHS(NRHS0 + I)
      END DO

C     .. Create outputs ..
      PLHS(1) = MXCREATEDOUBLEMATRIX(N, 1, 0)
      PX      = MXGETPR(PLHS(1))

      PLHS(2) = MXCREATEDOUBLEMATRIX(N, 1, 0)
      PY      = MXGETPR(PLHS(2))

      PLHS(3) = MXCREATEDOUBLEMATRIX(1, 1, 0)
      PIFLAG  = MXGETPR(PLHS(3))

      PLHS(4) = MXCREATEDOUBLEMATRIX(1, 1, 0)
      PNFEV   = MXGETPR(PLHS(4))

C     .. Computation ..
      CALL MXCOPYPTRTOREAL8(PX0, %val(PX), N)     
      NPRINT = -1 ! no special printing
      IFLAG  = -1 ! normal call
      LR     = N*(N+1)/2
      PFJAC  = MXGETPR(MXCREATEDOUBLEMATRIX( N, N, 0))
      PR     = MXGETPR(MXCREATEDOUBLEMATRIX(LR, 1, 0))
      PQTF   = MXGETPR(MXCREATEDOUBLEMATRIX( N, 1, 0))
      PWA1   = MXGETPR(MXCREATEDOUBLEMATRIX( N, 1, 0))
      PWA2   = MXGETPR(MXCREATEDOUBLEMATRIX( N, 1, 0))
      PWA3   = MXGETPR(MXCREATEDOUBLEMATRIX( N, 1, 0))
      PWA4   = MXGETPR(MXCREATEDOUBLEMATRIX( N, 1, 0))

      NFEV2  = 0

      WRITE(*, '( a6, $)') 'Calls'
      WRITE(*, '(a23, $)') '|f(x)|               '
      WRITE(*, '(a23, $)') '|x|                  ' 
      WRITE(*, '(a11   )') 'x        '

      CALL HYBRD(HYBRDFUN, N, %val(PX), %val(PY), %val(PXTOL),
     &           MAXFEV, ML, MU, %val(PEPSFCN), %val(PDIAG),
     &           MODE, %val(PFACTOR), NPRINT, IFLAG, NFEV,
     &           %val(PFJAC), N, %val(PR), LR, %val(PQTF),
     &           %val(PWA1), %val(PWA2), %val(PWA3), %val(PWA4))

      IIFLAG = DBLE(IFLAG)
      CALL MXCOPYREAL8TOPTR(IIFLAG, PIFLAG, 1)     

      NNFEV = DBLE(NFEV)
      CALL MXCOPYREAL8TOPTR(NNFEV, PNFEV, 1)     

      RETURN
      END
