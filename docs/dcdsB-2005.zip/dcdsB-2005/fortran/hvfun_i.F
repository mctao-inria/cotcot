      SUBROUTINE HVFUN_I(T, Z, HV) 
      IMPLICIT NONE
C     Written on Fri Mon Jan 10 12:12:06 CET 2005 
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function hv = hvfun(t, z, p1, ...). Defines the second member
C     of the BVP. Interface of HVFUN for ode solver. 

C     .. Global ..
      INTEGER          N
      INTEGER          LPAR
      INTEGER          PPAR

      COMMON           /CN/N
      COMMON           /CLPAR/LPAR
      COMMON           /CPPAR/PPAR

C     .. Arguments ..
C     T                (input) DOUBLE PRECISION
C                      Time
C     Z                (input) DOUBLE PRECISION array, dimension 2*N
C                      Costate and adjoint state
C     HV               (output) DOUBLE PRECISION array, dimension 2*N
C                      Second member of the BVP
      DOUBLE PRECISION T
      DOUBLE PRECISION Z(*)
      DOUBLE PRECISION HV(*)

C     .. First executable statement ..
      CALL HVFUN(T, N, Z, LPAR, %val(PPAR), HV)

      RETURN
      END
