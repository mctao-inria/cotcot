      SUBROUTINE MEXFUNCTION(NLHS, PLHS, NRHS, PRHS)
      IMPLICIT NONE
C     Written on Mon Jul 26 16:05:57 CEST 2004 
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function h = hfun_m(t, z, par).

C     .. Arguments ..
C     NLHS             (input) INTEGER
C                      Number of inputs
C     PLHS             (input) INTEGER array
C                      Inputs
C     NRHS             (input) INTEGER
C                      Number of outputs
C     PRHS             (input) INTEGER array
C                      Outputs
      INTEGER          NLHS
      INTEGER          NRHS
      INTEGER          PLHS(*)
      INTEGER          PRHS(*)

C     .. Local declarations ..
      INTEGER          DBSIZE
      PARAMETER       (DBSIZE = 8)
      INTEGER          NLHS0
      PARAMETER       (NLHS0 = 1)
      INTEGER          NRHS0
      PARAMETER       (NRHS0 = 3)
      INTEGER          PT
      INTEGER          PZ
      INTEGER          PPAR
      INTEGER          PH
      INTEGER          L
      INTEGER          I
      INTEGER          N
      INTEGER          LPAR
      INTEGER          MXGETPR
      INTEGER          MXCREATEDOUBLEMATRIX
      INTEGER          MXGETM
      INTEGER          MXGETN

C     .. Check inputs ..
      IF (NRHS.LT.NRHS0) THEN
        CALL MEXERRMSGTXT('Not enough input arguments.')
      ELSEIF (NRHS.GT.NRHS0) THEN
        CALL MEXERRMSGTXT('Too many input arguments.')
      ENDIF

C     .. Check outputs ..
      IF (NLHS.LT.NLHS0) THEN
        CALL MEXERRMSGTXT('Not enough output arguments.')
      ELSEIF (NLHS.GT.NLHS0) THEN
        CALL MEXERRMSGTXT('Too many output arguments.')
      ENDIF

C     .. Get inputs ..
      IF (MXGETM(PRHS(1)).NE.1) THEN
        CALL MEXERRMSGTXT('t must have one row.')
      ENDIF
      PT = MXGETPR(PRHS(1))
      L  = MXGETN(PRHS(1))

      IF (MXGETN(PRHS(2)).NE.L) THEN
        CALL MEXERRMSGTXT('y must have as many columns as t.')
      ENDIF
      PZ = MXGETPR(PRHS(2))
      N  = MXGETM(PRHS(2)) / 2

      PPAR = MXGETPR(PRHS(3))
      LPAR = MXGETM(PRHS(3)) * MXGETN(PRHS(3))

C    .. Create outputs ..
      PLHS(1) = MXCREATEDOUBLEMATRIX(1, L, 0)
      PH      = MXGETPR(PLHS(1))

C     .. Computation ..
      DO I = 0, (L-1)
        CALL HFUN(      %val(PT+I      *DBSIZE),
     &            N   , %val(PZ+I*(2*N)*DBSIZE),
     &            LPAR, %val(PPAR             ),
     &                  %val(PH+I*      DBSIZE))
      END DO

      RETURN
      END
