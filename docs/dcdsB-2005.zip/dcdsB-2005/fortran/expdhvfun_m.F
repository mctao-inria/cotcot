      SUBROUTINE MEXFUNCTION(NLHS, PLHS, NRHS, PRHS)
      IMPLICIT NONE
C     Written on Fri Jan  7 13:24:41 CET 2005
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function [ expdhv, iflag ] = expdhvfun_m(t, dz0, AbsTol, RelTol, par).

C     .. Global ..
      INTEGER          N
      INTEGER          K
      INTEGER          LPAR
      INTEGER          PPAR

      COMMON           /CN/N
      COMMON           /CK/K
      COMMON           /CLPAR/LPAR
      COMMON           /CPPAR/PPAR

C     .. Arguments ..
C     NLHS             (input) INTEGER
C                      Number of inputs
C     PLHS             (input) INTEGER array
C                      Inputs
C     NRHS             (input) INTEGER
C                      Number of outputs
C     PRHS             (input) INTEGER array
C                      Outputs
      INTEGER          NLHS
      INTEGER          NRHS
      INTEGER          PLHS(*)
      INTEGER          PRHS(*)

C     .. Local declarations ..
      INTEGER          DBSIZE
      PARAMETER       (DBSIZE = 8)
      INTEGER          NLHS0
      PARAMETER       (NLHS0 = 2)
      INTEGER          NRHS0
      PARAMETER       (NRHS0 = 5)
      INTEGER          PT
      INTEGER          PDZ0
      INTEGER          PABSTOL
      INTEGER          PRELTOL
      INTEGER          PEXPDHV
      INTEGER          PIFLAG
      INTEGER          I
      INTEGER          L
      INTEGER          IFLAG
      INTEGER          ODEIW(5)
      INTEGER          PODEW
      INTEGER          MXGETPR
      INTEGER          MXCREATEDOUBLEMATRIX
      INTEGER          MXGETM
      INTEGER          MXGETN
      DOUBLE PRECISION TIN
      DOUBLE PRECISION TOUT
      DOUBLE PRECISION IIFLAG
      EXTERNAL         DHVFUN_I

C     .. Checks inputs ..
      IF (NRHS.LT.NRHS0) THEN
        CALL MEXERRMSGTXT('Not enough input arguments.')
      ELSEIF (NRHS.GT.NRHS0) THEN
        CALL MEXERRMSGTXT('Too many input arguments.')
      ENDIF

C     .. Check outputs ..
      IF (NLHS.LT.NLHS0) THEN
        CALL MEXERRMSGTXT('Not enough output arguments.')
      ELSEIF (NLHS.GT.NLHS0) THEN
        CALL MEXERRMSGTXT('Too many output arguments.')
      ENDIF

C     .. Get inputs ..
      IF (MXGETM(PRHS(1)).NE.1) THEN
        CALL MEXERRMSGTXT('t must have one row')
      ELSEIF (MXGETN(PRHS(1)).LT.2) THEN
        CALL MEXERRMSGTXT('t must have at least 2 columns.')
      ENDIF
      PT = MXGETPR(PRHS(1))
      L  = MXGETN(PRHS(1))

      IF (MXGETN(PRHS(2)).LT.2) THEN
        CALL MEXERRMSGTXT('dy must have at least two columns.')
      ENDIF
      PDZ0 = MXGETPR(PRHS(2))
      N    = MXGETM(PRHS(2)) / 2
      K    = MXGETN(PRHS(2)) - 1

      IF (MXGETM(PRHS(3)) * MXGETN(PRHS(3)).NE.1) THEN
        CALL MEXERRMSGTXT('AbsTol must be scalar.')
      ENDIF
      PABSTOL = MXGETPR(PRHS(3))

      IF (MXGETM(PRHS(4)) * MXGETN(PRHS(4)).NE.1) THEN
        CALL MEXERRMSGTXT('RelTol must be scalar.')
      ENDIF
      PRELTOL = MXGETPR(PRHS(4))

      PPAR = MXGETPR(PRHS(5))
      LPAR = MXGETM(PRHS(5)) * MXGETN(PRHS(5))

C     .. Create outputs ..
      PLHS(1) = MXCREATEDOUBLEMATRIX(2*N, L*(1+K), 0)
      PEXPDHV = MXGETPR(PLHS(1))

      PLHS(2) = MXCREATEDOUBLEMATRIX(1, 1, 0)
      PIFLAG  = MXGETPR(PLHS(2))

C     .. Computation ..
      PODEW = MXGETPR(MXCREATEDOUBLEMATRIX(3+6*(2*N*(1+K)), 1, 0))
      CALL MXCOPYPTRTOREAL8(PDZ0, %val(PEXPDHV), 2*N*(1+K))
      DO I = 0, (L-2)
        CALL MXCOPYPTRTOREAL8(PT    + I         *DBSIZE, TIN , 1)
        CALL MXCOPYPTRTOREAL8(PT    +(I+1)      *DBSIZE, TOUT, 1)
        CALL MXCOPYPTRTOREAL8(PEXPDHV+ I   *(2*N*(1+K))*DBSIZE,
     &                   %val(PEXPDHV+(I+1)*(2*N*(1+K))*DBSIZE),
     &                   2*N*(1+K))
        IFLAG = 1 ! normal call

        CALL RKF45(DHVFUN_I, 2*N*(1+K),
     &             %val(PEXPDHV+(I+1)*(2*N*(1+K))*DBSIZE),
     &             TIN, TOUT, %val(PRELTOL), %val(PABSTOL),
     &             IFLAG, %val(PODEW), ODEIW)

        IF (IFLAG.NE.2) THEN
           CALL MEXWARNMSGTXT('Integration problem')
           WRITE(*, '(      a7,    i2,        a7, e23.15)')
     &               'iflag =', IFLAG, ' at t =',    TIN
        END IF
      END DO

      IIFLAG = DBLE(IFLAG)
      CALL MXCOPYREAL8TOPTR(IIFLAG, PIFLAG, 1)     

      RETURN
      END
