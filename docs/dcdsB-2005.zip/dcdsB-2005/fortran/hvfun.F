      SUBROUTINE HVFUN(T, N, Z, LPAR, PAR, HV) 
      IMPLICIT NONE
C     Written on Fri Dec 31 07:29:15 CET 2004
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function hv = hvfun(t, z, p1, ...). Defines the second member
C     of the BVP.

C     .. Global ..
#include "constants.h"

C     .. Arguments ..
C     T                (input) DOUBLE PRECISION
C                      Time
C     N                (input) INTEGER,
C                      State dimension
C     Z                (input) DOUBLE PRECISION array, dimension 2*N
C                      Costate and adjoint state
C     LPAR             (input) INTEGER,
C                      Number of optional parameters
C     PAR              (input) DOUBLE PRECISION array, dimension LPAR
C                      Optional parameters
C     HV               (output) DOUBLE PRECISION array, dimension 2*N
C                      Second member of the BVP
      INTEGER          N
      INTEGER          LPAR

      DOUBLE PRECISION T
      DOUBLE PRECISION Z(2*N)
      DOUBLE PRECISION PAR(LPAR)
      DOUBLE PRECISION HV(2*N)

C     .. Local declarations ..
      INTEGER          I
      INTEGER          J
      DOUBLE PRECISION G_Z(N2MAX, N2MAX)
      DOUBLE PRECISION G_H(N2MAX)
      DOUBLE PRECISION H

C     .. First executable statement ..
      IF (2*N.GT.N2MAX) THEN
        CALL MEXERRMSGTXT('Error: state dimension too large.')
      END IF

      DO I = 1,2*N
        DO J = 1,2*N
           G_Z(I,J) = 0.0D0
        END DO
      END DO
      DO I = 1,2*N
        G_Z(I,I) = 1.0D0
      END DO

      CALL G_HFUN(2*N, T, N, Z, G_Z, LPAR, PAR, H, G_H)

      DO I = 1,N
        HV(I)   =  G_H(N+I)
        HV(I+N) = -G_H(I)
      END DO

      RETURN
      END
