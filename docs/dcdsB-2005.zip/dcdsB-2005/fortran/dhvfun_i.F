      SUBROUTINE DHVFUN_I(T, DZ, DHV) 
      IMPLICIT NONE
C     Written on Fri Mon Jan 10 12:12:06 CET 2005 
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function dhv = dhvfun(t, dz, p1, ...). Defines the second member
C     of the variational system. Interface of DHVFUN for ode solver. 

C     .. Global ..
      INTEGER          N
      INTEGER          K
      INTEGER          LPAR
      INTEGER          PPAR

      COMMON           /CN/N
      COMMON           /CK/K
      COMMON           /CLPAR/LPAR
      COMMON           /CPPAR/PPAR

C     .. Arguments ..
C     T                (input) DOUBLE PRECISION
C                      Time
C     DZ               (input) DOUBLE PRECISION array, dimension 2*N*(1+K)
C                      Costate and adjoint state
C     DHV              (output) DOUBLE PRECISION array, dimension 2*N*(1+K)
C                      Second member of the variational system
      DOUBLE PRECISION T
      DOUBLE PRECISION DZ(*)
      DOUBLE PRECISION DHV(*)

C     .. First executable statement ..
      CALL DHVFUN(T, N, K, DZ, LPAR, %val(PPAR), DHV)

      RETURN
      END
