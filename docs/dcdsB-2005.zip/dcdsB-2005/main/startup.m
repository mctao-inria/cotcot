% startup.m
%

addpath('../matlab/');
addpath('../mex/');

% Written on Tue Jan 25 09:13:00 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT
