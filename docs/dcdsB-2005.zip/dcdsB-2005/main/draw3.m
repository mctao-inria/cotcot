function h = draw3(x, s, flag)
% draw3 -- Draws orbit transfer 
%
%  Usage
%    h = draw3(x[, s, flag])
%
%  Inputs
%    x      real vector, state
%    s      string, line style [   '*' ]
%    flag   boolean, hold flag [ false ]
%
%  Outputs
%    h      integer, handle to the plot
%
%  Description
%    Draws orbit transfer.
%
%  See also
%    draw1, draw2
%

global Tmax mass0 beta mu t0 tf x0 xf;

n     = size(x, 1);
N     = size(x, 2);
P     = x(1, :);
ex    = x(2, :);
ey    = x(3, :);
hx    = x(4, :);
hy    = x(5, :);
L     = x(6, :);

if nargin < 3 flag = 0; end;
if nargin < 2 s = ':+'; end;

W = 1+ex.*cos(L)+ey.*sin(L);
Z = hx.*sin(L)-hy.*cos(L);
C = 1+hx.^2+hy.^2;
q = zeros(3, N);
q(1, :) = P.*( (1+hx.^2-hy.^2).*cos(L) + 2*hx.*hy.*sin(L) ) ./ (C.*W);
q(2, :) = P.*( (1-hx.^2+hy.^2).*sin(L) + 2*hx.*hy.*cos(L) ) ./ (C.*W);
q(3, :) = 2*P.*Z ./ (C.*W);
v(1, :) = (1./C).*sqrt(mu./P).*( 2*hx.*hy.*(ex+cos(L))...,
- (1+hx.^2-hy.^2).*(ey+sin(L)) );
v(2, :) = (1./C).*sqrt(mu./P).*( (1-hx.^2+hy.^2).*(ex+cos(L))...,
- 2*hx.*hy.*(ey+sin(L)) );
v(3, :) = (2./C).*sqrt(mu./P).*(hx.*(ex+cos(L))+hy.*(ey+sin(L)));

subplot(5, 1, 1:3);
if flag hold; end;
plot3(q(1, :), q(2, :), q(3, :), s);
if flag hold; end;
xlabel('q_1');
ylabel('q_2');
zlabel('q_3');
axis equal;
daxes3(0, 0, 0, 'r');
drawnow;
zoom on;

subplot(5, 2, [7 9]);
if flag hold; end;
plot(q(1, :), q(2, :), s);
if flag hold; end;
xlabel('q_1');
ylabel('q_2');
axis equal;
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(5, 2, [8 10]);
if flag hold; end;
plot(q(2, :), q(3, :), s);
if flag hold; end;
xlabel('q_2');
ylabel('q_3');
daxes(0, 0, 'r');
drawnow;
zoom on;

h = gcf;

% Written on Sat Apr 30 16:58:03 CEST 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
