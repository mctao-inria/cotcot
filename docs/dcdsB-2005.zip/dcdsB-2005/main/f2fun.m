function f2 = f2fun(x)
% f2fun -- Vector field f2
%
%  Usage
%    f2 = f2fun(x)
%
%  Inputs
%    x      real vector, state
%
%  Outputs
%    f2     real vector, vector field at x
%
%  Description
%    Computes vector field f2.
%

global Tmax mass0 beta mu t0 tf x0 xf;

P  = x(1, :);
ex = x(2, :);
ey = x(3, :);
hx = x(4, :);
hy = x(5, :);
L  = x(6, :);

W  = 1 + ex.*cos(L) + ey.*sin(L);
z  = zeros(1, size(x, 2));

f2 = [ sqrt(P/mu) .* (2.*P./W)
       sqrt(P/mu) .* (cos(L)+(ex+cos(L))./W)
	 sqrt(P/mu) .* (sin(L)+(ey+sin(L))./W)
	 z
	 z
	 z ];

% Written on Thu Jan 13 10:26:15 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
