function [ h, u, de, sv ] = draw2(t, dy)
% draw2 -- Draws orbit transfer 
%
%  Usage
%    [ h, u, de, sv ] = draw2(t, dy)
%
%  Inputs
%    t      real, time
%    dy     real matrix, Jacobi fields
%
%  Outputs
%    h      integer, handle to the first plot
%    u      real vector, control
%    de     real, det of Jacobi fields
%    sv     real vector, svd of Jacobi fields
%
%  Description
%    Draws minimum time transfer and conjugate points, fixed Lf
%    (regular case).
%
%  See also
%    draw1
%

global Tmax mass0 beta mu t0 tf x0 xf;

N     = size( t, 2);
n     = size(x0, 1);
k     = size(dy, 2)/N - 1;
if (k~= (n-1)) error('Number of Jacobi fields should be (n-1).'); end;
y     = dy(:, 1:(k+1):end);
tc    = t(end);

% figs 1 to 3
[ h, u ] = draw1(t, y);

% fig4: conjugate points (regular case, k = n-1)
fig4 = 4;
figure(fig4);
set(fig4, 'Position', [270    10   420   270]);
orient('portrait');

de = zeros(1, N);
sv = zeros(n-1, N);
hv = hvfun(t, y, Tmax, mass0, beta, mu);

for i = 1:N
  dx       = dy(1:n, (2+(i-1)*(k+1)):(i*(k+1)));
  dx       = [ dx hv(1:n, i) ];
  sv(:, i) = svd(dx(:, 1:n-1));
  de(i)    = det(dx);
end;

subplot(2, 1, 1);
plot(t, asinh(de));
hold on ; m = max(abs(asinh(de))); plot(t, m*sign(de), 'k--'); hold off;
ax = axis; axis([ t(1) t(end) ax(3) ax(4) ]);
xlabel('t');
ylabel('arcsh det(\delta x)');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(2, 1, 2);
plot(t, sv(n-1, :));
ax = axis; axis([ t(1) t(end) ax(3) ax(4) ]);
xlabel('t');
ylabel('\sigma_{n-1}');
daxes(0, 0, 'r');
drawnow;
zoom on;

% Written on Tue Jan 11 19:38:13 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
