      SUBROUTINE HFUN(T, N, Z, LPAR, PAR, H) 
      IMPLICIT NONE
C     Written on Fri Dec 31 07:29:15 CET 2004
C     by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
C
C     Function h = hfun(t, y, p1, ...). Hamiltonian of the problem.

C     .. Arguments ..
C     T                (input) DOUBLE PRECISION
C                      Time
C     N                (input) INTEGER,
C                      State dimension
C     Z                (input) DOUBLE PRECISION array, dimension 2*N
C                      Costate
C     LPAR             (input) INTEGER,
C                      Number of optional parameters
C     PAR              (input) DOUBLE PRECISION array, dimension LPAR
C                      Optional parameters
C     H                (output) DOUBLE PRECISION
C                      Hamiltonian
      INTEGER          N
      INTEGER          LPAR

      DOUBLE PRECISION T
      DOUBLE PRECISION Z(2*N)
      DOUBLE PRECISION PAR(LPAR)
      DOUBLE PRECISION H

C     .. Local declarations ..
      DOUBLE PRECISION TMAX
      DOUBLE PRECISION BETA
      DOUBLE PRECISION MASS0
      DOUBLE PRECISION MU
      DOUBLE PRECISION PA
      DOUBLE PRECISION EX
      DOUBLE PRECISION EY
      DOUBLE PRECISION HX
      DOUBLE PRECISION HY
      DOUBLE PRECISION LG
      DOUBLE PRECISION PDM
      DOUBLE PRECISION CL
      DOUBLE PRECISION SL
      DOUBLE PRECISION W
      DOUBLE PRECISION PDMW
      DOUBLE PRECISION ZZ
      DOUBLE PRECISION UH
      DOUBLE PRECISION F06
      DOUBLE PRECISION F12
      DOUBLE PRECISION F13
      DOUBLE PRECISION F21
      DOUBLE PRECISION F22
      DOUBLE PRECISION F23
      DOUBLE PRECISION F32
      DOUBLE PRECISION F33
      DOUBLE PRECISION F34
      DOUBLE PRECISION F35
      DOUBLE PRECISION F36
      DOUBLE PRECISION H0
      DOUBLE PRECISION H1
      DOUBLE PRECISION H2
      DOUBLE PRECISION H3
      DOUBLE PRECISION MASS
      DOUBLE PRECISION PSI

C     .. First executable statement ..
      IF (N.NE.6) THEN
        CALL MEXERRMSGTXT('Error: state dimension should be 6.')
      END IF
      PA = Z(1)
      EX = Z(2)
      EY = Z(3)
      HX = Z(4)
      HY = Z(5)
      LG = Z(6)

      IF (LPAR.NE.4) THEN
        CALL MEXERRMSGTXT('Error: number of parameters should be 4.')
      END IF
      TMAX  = PAR(1)
      MASS0 = PAR(2)
      BETA  = PAR(3)
      MU    = PAR(4)

      PDM = SQRT(PA/MU) 
      CL = COS(LG)
      SL = SIN(LG)
      W = 1+EX*CL+EY*SL
      PDMW = PDM/W 
      ZZ = HX*SL-HY*CL
      UH = (1+HX**2+HY**2)/2.0D0

      F06 = W**2/(PA*PDM)
      H0  = Z(N+6)*F06

      F12 = PDM *   SL
      F13 = PDM * (-CL)
      H1  = Z(N+2)*F12 + Z(N+3)*F13

      F21 = PDM * 2.0D0 * PA / W
      F22 = PDM * (CL+(EX+CL)/W)
      F23 = PDM * (SL+(EY+SL)/W)
      H2  = Z(N+1)*F21 + Z(N+2)*F22 + Z(N+3)*F23

      F32 = PDMW * (-ZZ*EY)
      F33 = PDMW * ZZ*EX
      F34 = PDMW * UH * CL
      F35 = PDMW * UH * SL
      F36 = PDMW * ZZ
      H3  =
     &Z(N+2)*F32 + Z(N+3)*F33 + Z(N+4)*F34 + Z(N+5)*F35 + Z(N+6)*F36

      MASS = MASS0 - BETA*TMAX*T
      IF (MASS.LE.0.0D0) THEN
        WRITE(*, '(     a6, e23.15)')
     &            'At t =',    T
        CALL MEXERRMSGTXT('Error: negative mass.') 
      END IF

      PSI = SQRT(H1**2 + H2**2 + H3**2)
      IF (PSI.EQ.0.0D0) THEN
        WRITE(*, '(     a6, e23.15)')
     &            'At t =',    T
        CALL MEXERRMSGTXT('Error: exact switching.')
      END IF

      H = -1.0D0 + H0 + (TMAX/MASS) * PSI
       
      RETURN
      END
