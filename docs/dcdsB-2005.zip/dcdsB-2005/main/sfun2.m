function s = sfun2(xi, options)
% sfun2 -- Shooting function 2
%
%  Usage
%    s = sfun2(xi, options)
%
%  Inputs
%    xi      real vector, shooting variable
%    options struct, options passed to exphvfun
%
%  Outputs
%    s      real vector, shooting value
%
%  Description
%    Computes the shooting function, min time and fixed Lf problem.
%
%  See also
%    exphvfun
%

global Tmax mass0 beta mu t0 tf x0 xf;

tf  = xi(1);
p0  = xi(2:end);

t  = [ t0 tf ];
z0 = [ x0; p0 ];
[ z, iflag ] = exphvfun(t, z0, options, Tmax, mass0, beta, mu);
zf = z(:, end);
s = zf(1:6) - xf(1:6); % fixed Lf
h = hfun(tf, zf, Tmax, mass0, beta, mu); 
s = [ s; h ]; % free tf

% Written on Tue Jan 11 13:07:08 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
