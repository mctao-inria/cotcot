function [ h, de, sv ] = draw4(t, dz)
% draw2 -- Draws orbit transfer 
%
%  Usage
%    [ h, de, sv ] = draw2(t, dz)
%
%  Inputs
%    t      real, time
%    dz     real matrix, Jacobi fields
%
%  Outputs
%    h      integer, handle to the first plot
%    de     real, det of Jacobi fields
%    sv     real vector, svd of Jacobi fields
%
%  Description
%    Draws minimum time transfer and conjugate points, fixed Lf
%    (regular case).
%
%  See also
%    draw2
%

global Tmax mass0 beta mu t0 tf x0 xf;

N     = size( t, 2);
n     = size(x0, 1);
k     = size(dz, 2)/N - 1;
if (k~= (n-1)) error('Number of Jacobi fields should be (n-1).'); end;
z     = dz(:, 1:(k+1):end);
tc    = t(end);

% fig4: conjugate points (regular case, k = n-1)
fig4 = 4;
figure(fig4);
set(fig4, 'Position', [270    10   420   270]);
orient('portrait');

de = zeros(1, N);
sv = zeros(n-1, N);
hv = hvfun(t, z, Tmax, mass0, beta, mu);

for i = 1:N
  dx       = dz(1:n, (2+(i-1)*(k+1)):(i*(k+1)));
  dx       = [ dx hv(1:n, i) ];
  sv(:, i) = svd(dx(:, 1:n-1));
  de(i)    = det(dx);
end;

subplot(2, 1, 1);
plot(t, asinh(de));
hold on ; m = max(abs(asinh(de))); plot(t, m*sign(de), 'k--'); hold off;
ax = axis; axis([ t(1) t(end) ax(3) ax(4) ]);
xlabel('t');
ylabel('arcsh det(\delta x)');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(2, 1, 2);
plot(t, sv(n-1, :));
ax = axis; axis([ t(1) t(end) ax(3) ax(4) ]);
xlabel('t');
ylabel('\sigma_{n-1}');
daxes(0, 0, 'r');
drawnow;
zoom on;

h = fig4;

% Written on Sun May  1 00:23:44 CEST 2005  
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
