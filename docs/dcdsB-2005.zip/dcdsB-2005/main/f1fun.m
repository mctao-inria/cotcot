function f1 = f1fun(x)
% f1fun -- Vector field f1
%
%  Usage
%    f1 = f1fun(x)
%
%  Inputs
%    x      real vector, state
%
%  Outputs
%    f1     real vector, vector field at x
%
%  Description
%    Computes vector field f1.
%

global Tmax mass0 beta mu t0 tf x0 xf;

P  = x(1, :);
ex = x(2, :);
ey = x(3, :);
hx = x(4, :);
hy = x(5, :);
L  = x(6, :);

z  = zeros(1, size(x, 2));

f1 = [ z
       sqrt(P/mu) .* ( sin(L))
	 sqrt(P/mu) .* (-cos(L))
	 z
	 z
	 z ];

% Written on Thu Jan 13 10:26:15 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
