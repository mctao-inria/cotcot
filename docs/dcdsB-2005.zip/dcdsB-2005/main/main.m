% main.m -- "Geometric optimal control of elliptic Keplerian orbits"
% Bernard Bonnard, Jean-Baptiste Caillau and Emmanuel Trélat
% Discrete and Continuous Dynamical Systems-Series B, Vol. 5:4, pp. 929-956,
% 2005
%

ti =      '\t\b"Geometric optimal control of elliptic Keplerian orbits"\n';
ti = [ ti '\tBernard Bonnard, Jean-Baptiste Caillau and Emmanuel Trelat\n' ];
ti = [ ti '\tDiscrete and Continuous Dynamical Systems-Series B\n'];
ti = [ ti '\tVol. 5:4, pp. 929-956, 2005' ] ;
title = ti;
entries = [ 'Figure 1                ';
	      'Figure 2                ' ];
nentries = size(entries,1);

fprintf(1,'\n');
fprintf(1, [ title '\n' ]);
fprintf(1,'\n');
for i = 1:nentries
  fprintf(1,'\t%d. %s\n',i,entries(i,:));
end;
fprintf(1,'\n');
fprintf(1,'\t0. Quit\n');
fprintf(1,'\n');

ch = -1; while (ch == -1)
  fprintf(1,'Choice ? '); ch = input('');
  if isempty(ch) ch = -1; end;
  if (ch < 0) | (ch > nentries) ch = -1; end;
end;

if (ch == 0)
  close all
else
  fprintf(1,'\n%d. %s\n\n',ch,entries(ch,:));
  eval(['fig' num2str(ch)]);
  main;
end;

% Written on Tue Jan 11 18:42:32 CET 2005
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
