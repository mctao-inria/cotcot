function f3 = f3fun(x)
% f3fun -- Vector field f3
%
%  Usage
%    f2 = f2fun(x)
%
%  Inputs
%    x      real vector, state
%
%  Outputs
%    f2     real vector, vector field at x
%
%  Description
%    Computes vector field f2.
%

global Tmax mass0 beta mu t0 tf x0 xf;

P  = x(1, :);
ex = x(2, :);
ey = x(3, :);
hx = x(4, :);
hy = x(5, :);
L  = x(6, :);

W  = 1 + ex.*cos(L) + ey.*sin(L);
Z  = hx.*sin(L) - hy.*cos(L);
C  = 1 + hx.^2 + hy.^2;
z  = zeros(1, size(x, 2));

f3 = [ z
       sqrt(P/mu) .* (-Z.*ey./W)
	 sqrt(P/mu) .* ( Z.*ex./W)
	 sqrt(P/mu) .* C.*cos(L)./(2.*W)
	 sqrt(P/mu) .* C.*sin(L)./(2.*W)
	 sqrt(P/mu) .* (Z./W) ];

% Written on Thu Jan 13 10:26:15 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
