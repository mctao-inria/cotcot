function u = ufun(t, y)
% ufun -- Control
%
%  Usage
%    u = ufun(t, y)
%
%  Inputs
%    t      real, time
%    y      real vector, state and costate
%
%  Outputs
%    u      real vector, control at time t
%
%  Description
%    Computes the control as a function of t and y (dynamic feedback).
%

global Tmax mass0 beta mu t0 tf x0 xf;

n = size(y, 1) / 2;
N = size(y, 2);
x = y(    1:n, :);
p = y(n+1:2*n, :);

psi      = zeros(3, N);
psi(1,:) = dot(p, f1fun(x));
psi(2,:) = dot(p, f2fun(x));
psi(3,:) = dot(p, f3fun(x));

npsi = dot(psi, psi, 1).^.5;
u    = Tmax * psi ./ [ npsi; npsi; npsi ];

% Written on Thu Jan 13 10:26:15 CET 2005
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
