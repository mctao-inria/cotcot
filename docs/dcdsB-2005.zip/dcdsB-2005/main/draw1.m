function [ h, u ] = draw1(t, y)
% draw1 -- Draws orbit transfer 
%
%  Usage
%    [ h, u ] = draw1(t, y)
%
%  Inputs
%    t      real, time
%    y      real vector, extremal
%
%  Outputs
%    h      integer, handle to the first plot
%    u      real matrix, control
%
%  Description
%    Draws minimum time transfer, free Lf.
%
%  See also
%    draw2
%

global Tmax mass0 beta mu t0 tf x0 xf;

N     = size( t, 2);
n     = size(x0, 1);
x     = y(    1:n, :);
p     = y(n+1:2*n, :);
P     = x(1, :);
ex    = x(2, :);
ey    = x(3, :);
hx    = x(4, :);
hy    = x(5, :);
L     = x(6, :);
mass  = mass0 - beta*Tmax*t;
u     = ufun(t, y);

% fig1: state, mass and control
fig1 = 1;
figure(fig1);
set(fig1, 'Position', [ 270   370   420   290 ]);
orient('tall');

subplot(7, 2, 1);
plot(t, P);
ax = axis; axis([ t(1) t(end) ax(3) ax(4) ]);
xlabel('t');
ylabel('P');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 2);
plot(t, L);
ax = axis; axis([ t(1) t(end) ax(3) ax(4) ]);
xlabel('t');
ylabel('L');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 3);
plot(t, ex);
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('e_x');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 4);
plot(t, hx);
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('h_x');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 5);
plot(t, ey);
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('e_y');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 6);
plot(t, hy);
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('h_y');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 1, 4);
plot(t, mass);
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('m');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 1, 5);
plot(t, u(1, :));
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('u_1');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 1, 6);
plot(t, u(2, :));
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('u_2');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 1, 7);
plot(t, u(3, :));
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('u_3');
daxes(0, 0, 'r');
drawnow;
zoom on;

% fig2: trajectory
fig2 = 2;
figure(fig2);
set(fig2, 'Position', [710   370   420   290]);

W = 1+ex.*cos(L)+ey.*sin(L);
Z = hx.*sin(L)-hy.*cos(L);
C = 1+hx.^2+hy.^2;
q = zeros(3, N);
q(1, :) = P.*( (1+hx.^2-hy.^2).*cos(L) + 2*hx.*hy.*sin(L) ) ./ (C.*W);
q(2, :) = P.*( (1-hx.^2+hy.^2).*sin(L) + 2*hx.*hy.*cos(L) ) ./ (C.*W);
q(3, :) = 2*P.*Z ./ (C.*W);
v(1, :) = (1./C).*sqrt(mu./P).*( 2*hx.*hy.*(ex+cos(L))...,
- (1+hx.^2-hy.^2).*(ey+sin(L)) );
v(2, :) = (1./C).*sqrt(mu./P).*( (1-hx.^2+hy.^2).*(ex+cos(L))...,
- 2*hx.*hy.*(ey+sin(L)) );
v(3, :) = (2./C).*sqrt(mu./P).*(hx.*(ex+cos(L))+hy.*(ey+sin(L)));
qq = q; nqq = (dot(qq, qq, 1).^.5); qq = qq ./ [ nqq; nqq; nqq ];
ww = cross(q, v); nww = (dot(ww, ww, 1).^.5); ww = ww ./ [ nww; nww; nww ];
ss = cross(ww, qq);
uc = zeros(size(u));
for i = 1:N
  uc(:, i) = [ qq(:, i) ss(:, i) ww(:, i) ] * u(:, i);
end;

subplot(5, 1, 1:3);
plot3(q(1, :), q(2, :), q(3, :));
%step = 1;
step = 20;
i = 1:step:N;
hold on;
quiver3(q(1, i), q(2, i), q(3, i), uc(1, i), uc(2, i), uc(3, i), 'r');
hold off;
xlabel('q_1');
ylabel('q_2');
zlabel('q_3');
axis equal;
daxes3(0, 0, 0, 'r');
drawnow;
zoom on;

subplot(5, 2, [7 9]);
plot(q(1, :), q(2, :));
xlabel('q_1');
ylabel('q_2');
axis equal;
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(5, 2, [8 10]);
plot(q(2, :), q(3, :));
xlabel('q_2');
ylabel('q_3');
daxes(0, 0, 'r');
%axis([-47 47 -2.4 2.4]); % debug (probably to delete)
drawnow;
zoom on;

% fig3: adjoint state and psi
fig3 = 3;
figure(fig3);
set(fig3, 'Position', [710    10   420   270]);
orient('tall');

subplot(7, 2, 1);
plot(t, p(1, :));
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('p_P');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 2);
plot(t, p(6, :));
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('p_L');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 3);
plot(t, p(2, :));
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('p_{e_x}');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 4);
plot(t, p(4, :));
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('p_{h_x}');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 5);
plot(t, p(3, :));
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('p_{e_y}');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 2, 6);
plot(t, p(5, :));
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('p_{h_y}');
daxes(0, 0, 'r');
drawnow;
zoom on;

psi      = zeros(3, N);
psi(1, :) = dot(p, f1fun(x));
psi(2, :) = dot(p, f2fun(x));
psi(3, :) = dot(p, f3fun(x));

npsi = (dot(psi, psi, 1).^.5); 
subplot(7, 1, 4:5);
plot(t, npsi);
ax = axis; axis([t(1) t(end) ax(3) ax(4)]);
xlabel('t');
ylabel('|\psi|');
daxes(0, 0, 'r');
drawnow;
zoom on;

subplot(7, 1, 6:7);
plot3(psi(1, :), psi(2, :), psi(3, :));
daxes3(0, 0, 0, 'r');
xlabel('\psi_1');
ylabel('\psi_2');
zlabel('\psi_3');
drawnow;
zoom on;

h = fig1;

% Written on Tue Jan 11 19:38:13 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
