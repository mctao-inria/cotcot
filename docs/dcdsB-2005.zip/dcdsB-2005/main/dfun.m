function d = dfun(t, t1, dz1, options)
% dfun -- Det of Jacobi fields
%
%  Usage
%    d = dfun(t, t1, dz1, options)
%
%  Inputs
%    t      real, time
%    t1     real, initial time
%    dz1    real matrix, initial flow
%    options struct, options passed to expdhvfun
%
%  Outputs
%    d      real, det
%
%  Description
%    Computes the determinant of Jacobi fields with dynamics at time t.
%
%  See also
%    expdhvfun
%

global Tmax mass0 beta mu t0 tf x0 xf;

n = size(dz1, 1)/2;

[ dz, iflag ] = expdhvfun([ t1 t ], dz1, options, Tmax, mass0, beta, mu);
z  = dz(:, n+1);
hv = hvfun(t, z, Tmax, mass0, beta, mu);
dx = [ hv(1:n) dz(1:n, n+2:end) ];

d = det(dx);

% Written on Tue Jan 18 19:00:52 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
