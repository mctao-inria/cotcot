#define N2MAX 32
