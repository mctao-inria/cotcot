Do a make, then run main/main.m under Matlab.
