function h = hfun(t, z, varargin)
% hfun -- Hamiltonian.
%
%  Usage
%    h = hfun(t, z, p1, ...)
%
%  Inputs
%    t      real, time
%    z      real vector, state and costate
%    p1     any, optional argument
%    ...
%
%  Outputs
%    h      real, Hamiltonian at time t
%
%  Description
%    Computes the Hamiltonian.
%

par = [];
nrhs0 = 2;
for i = 1:(nargin-nrhs0)
  par = [ par varargin{i}(:)' ];
end;

h = hfun_m(t, z, par);

% Written on Tue Jan 11 16:19:36 CET 2005 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
