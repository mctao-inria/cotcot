function hv = hvfun(t, z, varargin)
% hvfun -- Vector field associated to H.
%
%  Usage
%    hv = hvfun(t, z, p1, ...)
%
%  Inputs
%    t      real, time
%    z      real vector, state and costate
%    p1     any, optional argument
%    ...
%
%  Outputs
%    hv     real matrix, vector H at time t
%
%  Description
%    Computes the Hamiltonian vector field associated to H.
%

par = [];
nrhs0 = 2;
for i = 1:(nargin-nrhs0)
  par = [ par varargin{i}(:)' ];
end;

hv = hvfun_m(t, z, par);

% Written on Fri Jan  7 12:38:41 CET 2005
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
