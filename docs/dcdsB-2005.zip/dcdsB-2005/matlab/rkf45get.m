function value = rkf45get(options, name)
% rkf45get -- Gets rkf45 options.
%
%  Usage
%    value = rkf45get(options, name)
%
%  Inputs
%    options struct, options
%    name    string, option name
%
%  Outputs
%    value   any, option value
%
%  Description
%    Options are:
%      AbsTol - Absolute error tolerance [ 1e-14 ]
%      RelTol - Relative error tolerance [  1e-8 ]
%
%  See also
%    rkf45, rkf45set
%

switch lower(name)
  case 'abstol'
    value = options.AbsTol;
  case 'reltol'
    value = options.RelTol;
  otherwise
    error(sprintf('Unrecognized property name ''%s''.', name));
end;

% Written on Fri Oct  1 11:05:34 CEST 2004 
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
