function [ expdhv, iflag ] = expdhvfun(t, dz0, options, varargin)
% exphvfun -- Exponential of dhv/dz
%
%  Usage
%    [ expdhv, iflag ] = expdhvfun(t, dz0, options, p1, ...)
%
%  Inputs
%    t      real, time 
%    dz0    real matrix, initial flow
%    options struct vector, options
%    p1     any, optional arguments passed to dhvfun
%    ...
%
%  Outputs
%    expdhv real matrix, flow at time t 
%    iflag  integer, ODE solver output (should be 2)
%
%  Description
%    Computes the (right) chronological exponential of the variational
%    system associated to hv.
%
%  See also
%    exphvfun, rkf45set, rkf45get
%

par = [];
nrhs0 = 3;
for i = 1:(nargin-nrhs0)
  par = [ par varargin{i}(:)' ];
end;

[ expdhv, iflag ] = expdhvfun_m(t, dz0, options.AbsTol, options.RelTol, par);

% Written on Fri Jan  7 12:38:41 CET 2005
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
