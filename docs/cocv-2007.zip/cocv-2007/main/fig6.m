% fig6.m -- "Second order optimality conditions in the smooth case and
% applications in optimal control"
% Bernard Bonnard, Jean-Baptiste Caillau and Emmanuel Trélat
% Submitted to ESAIM Control, Optimisation and Calculus of Variations, 2005
%

format long;
clear all, close all;
global Tmax mass0 beta mu t0 tf x0 xf;

% Definitions
cTmax = (3600^2) / 1e6; % conversion from Newtons
beta = 1.42e-02;
mu = 5165.8620912;
t0 = 0;
x0 = [ 11.625 0.75 0 6.12e-02 0 3.14159265358979 ]';
n = size(x0, 1); % state dimension
mass0 = 1500;
xf = [ 42.165 0 0 0 0 0 ]'; % fixed Lf (conjugate points)

% Initializations, fixed Lf (sfun2)
%Tmax = cTmax*60, zi = -[ -1.480036435528265e+01 3.909119415268183e-01 2.193609839175358e+01 7.853625755046798e+00 2.281096308460278e+00 -8.287518228783126e-01 -5.839499708548173e+00 ]'; xf(6) = 10; nc = 8;
%Tmax = cTmax*24, zi = -[ -3.471682185279475e+01 -8.661686578219130e-01 3.137936673665401e+00 3.417402373794388e-01 1.467365280100847e+01 -2.467496920859010e+00 -1.052943662642679e-01 ]'; xf(6) = 17; nc = 8;
%Tmax = cTmax*12, zi = -[ -7.024997920744275e+01 -1.744973420489689e+00 2.232563692421648e+00 7.934346401833985e-01 2.774454892431760e+01 -2.370251055338129e+00 -4.500166041343288e-01 ]'; xf(6) = 30; nc = 8;
%Tmax = cTmax*9, zi = -[ -9.327255393283608e+01 -4.743728521400288e+00 -7.171314803577050e+01 -2.750468259255777e+00 4.505679920818070e+01 -3.026794469744788e+00 2.248091027899508e+00 ]'; xf(6) = 36; nc = 8;
Tmax = cTmax*6, zi = -[ -1.412269502058195e+02 -6.056349904490734e+00 -8.358368266787751e+01 -1.247768970984351e+00 5.963335541928215e+01 -1.439431985568195e+00 1.023919972601253e+00 ]'; xf(6) = 51; nc = 4;
%Tmax = cTmax*3, zi = -[ -2.857706952702574e+02 -7.514857972331259e+00 -2.266560930634657e+01 1.035935940527237e+00 1.040962247421422e+02 -2.285468040730434e+00 -6.370813079128220e-01 ]'; xf(6) = 103; nc = 3.6;
%Tmax = cTmax*2, zi = -[ -4.256103244289019e+02 -1.777726725198671e+01 -2.367876825465815e+02 -1.062418312201876e+00 1.790235297390916e+02 -2.657949122228808e+00 9.594802238394682e-01 ]'; xf(6) = 147; nc = 8;
%Tmax = cTmax*1.4, zi = -[ -6.061334961153259e+02 -2.694669504192490e+01 -3.830090289207805e+02 -1.552453422672556e+00 2.624568469342512e+02 -1.661208772666790e+00 1.266006046600553e+00 ]'; xf(6) = 208; nc = 8;
%Tmax = cTmax*0.5, zi = -[ -1.700977206879903e+03 -6.074895524234615e+01 -6.079191717513437e+02 -3.159694169743349e-01 6.883977066524844e+02 -2.529481135350224e+00 3.917816462716960e-01 ]'; xf(6) = 565; nc = 5;

% Extremal
odeopt = rkf45set;
nleopt = hybrdset;
tic; [ z, s, iflag, nfev ] = hybrd('sfun2', zi, nleopt, odeopt), toc
tf = z(1), p0 = z(2:end);

% Jacobi fields
k = n-1; % regular case, free tf
N = 10000;
tc = nc * tf;
dt = tc/N;
t  = t0:dt:tc;
y0 = [ x0; p0 ];
[ dummy, dp0 ] = gram(p0);
dy0 = [ zeros(n, k); dp0 ]; dy0 = [ y0 dy0 ];
[ dy, iflag ] = expdhvfun(t, dy0, odeopt, Tmax, mass0, beta, mu); iflag 

% Graphs
[ h, u, de, sv ] = draw2(t, dy);
itcs = find((de(1:end-1).*de(2:end)) <= 0);
itcs = itcs(2:end);
tcs  = t(itcs)

% More...
figure(h+3);
for i = 1:length(tcs)
  t1 = tcs(i);
  dy1 = dy(:, 1+(itcs(i)-1)*(k+1):itcs(i)*(k+1)); 
  tic; [ tcs(i), d, iflag, nfev ] = hybrd('dfun', t1, nleopt, ...
                                          t1, dy1, odeopt); iflag, toc
  subplot(2, 1, 1), hold on, plot(tcs(i), 0,'g*'), hold off, drawnow;
  subplot(2, 1, 2), hold on, plot(tcs(i), 0,'g*'), hold off, drawnow;
end;
zoom on;
tcs

% Written on Tue Jan 11 18:42:32 CET 2005
% by Jean-Baptiste Caillau - ENSEEIHT-IRIT (UMR CNRS 5505)
